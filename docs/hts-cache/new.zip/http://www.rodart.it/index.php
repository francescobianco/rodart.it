<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Home&nbsp;-&nbsp;Rosalba D&#039;Arienzo,ROD&#039;A&#039;,artista,pittrice,decoratrice,quadri rod&#039;�,quadri rosalba d&#039;arienzo,rodart,opere rosalba d&#039;arienzo,opere rod&#039;�</title>
<meta name="description" content="" />
<meta name="keywords" content="quadri,pittura,decorazioni,arte" />
<meta name="Generator" content="Joomla! - Copyright (C) 2005 - 2008 Open Source Matters. Tutti i diritti riservati." />
<meta name="robots" content="index, follow" />
<base href="http://www.rodart.it/" />
	<link rel="shortcut icon" href="http://www.rodart.it/images/favicon.ico" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="http://www.rodart.it/templates/roda/css/template_css.css" rel="stylesheet" type="text/css"/>
</head>
<body>

	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-37929888-1']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>

	<a style="display:none;" href="http://www.archeocultura.net" alt="Archeologia e Cultura Archeocultura.net">Archeocultura.net</a>
	<div class="roda-body">
		<div class="roda-page">
			<div class="roda-header">
			</div>
										
							<div class="roda-middlehome">
					<div class="roda-middlehome-box">
						<div class="roda-middlehome-left">
							<table class="blog" cellpadding="0" cellspacing="0"><tr><td valign="top"><div>				<table class="contentpaneopen">
			<tr>
								<td class="contentheading" width="100%">
					Presentazione									</td>
							</tr>
			</table>
			
		<table class="contentpaneopen">
				<tr>
			<td valign="top" colspan="2">
				<p>E&#39; difficile presentare Rod&#39;A&#39; per quella poliedricit&agrave; e quella originalit&agrave; che contraddistinguono la sua arte.</p><p>Ma &egrave; sufficiente pensare a lei cos&igrave; com&#39;&egrave;, con li suo volto bello, solare, che parla gi&agrave; dell&#39;umanit&agrave; racchiusa nelle figure che dipinge, utilizzando spesso il rosso che esprime la sua passionalit&agrave;, e il nero il mistero, la profondit&agrave; del suo animo, ma anche il bianco e l&#39;oro, simbolo di purezza e di un romantico abbandono a una allegria di fanciulla, che si entusiasma con un candore che &egrave; propio del suo cuore.</p><p>Figure tragiche e comiche, figure nelle quali si incontrano mondi diversi, personaggi della mitologia greca o di varie etnie, intriganti, interessanti che attraggono come richiami sottili, silenziosi, come musica o poesia.</p><p>Rosalba o Rod&#39;A&#39; non si limita a ritrarre corpi, ma anime ricche interiormante e lei, cos&igrave; vogliosa e ricca di iniziativa, esprime tutto un universo di emozioni, sensazioni, conoscenze, cos&igrave; come i grandi artisti, ora come nel passato, hanno fatto, donando al pubblico che li ama, preziosi capolavori d&#39;arte.</p><p>Raffinata ed elegante, nella vita come nell&#39;arte, &egrave; nella spiritualit&agrave; e&nbsp; nell&#39;esistenziale che trova la linfa da cui trarre ispirazione.</p><p><em>Maria Rita Crifasi</em> </p>			</td>
		</tr>
				</table>

		<span class="article_seperator">&nbsp;</span>

		</div></td></tr></table>	
						</div>
						<div class="roda-middlehome-right">
									<div class="moduletable-mh">
			<ul id="mainlevel-mh"><li><a href="http://www.rodart.it/biografia.html" class="mainlevel-mh" >Biografia</a></li><li><a href="http://www.rodart.it/recensioni.html" class="mainlevel-mh" >Recensioni</a></li><li><a href="http://www.rodart.it/pagine/dicono-di-me.html" class="mainlevel-mh" >Dicono di me</a></li><li><a href="http://www.rodart.it/pagine/curriculum.html" class="mainlevel-mh" >Curriculum</a></li><li><a href="http://www.rodart.it/galleria.html" class="mainlevel-mh" >Galleria</a></li><li><a href="http://www.rodart.it/contatti/rod-a/rosalba-darienzo.html" class="mainlevel-mh" >Contatti</a></li></ul>		</div>
				<div class="moduletable_newshome">
							<h3>
					Notizie				</h3>
				<div class="flexcontent_newshome"><div class="flexcontentitem_newshome"><h3 class="flexcontentitemtitle"><a href="http://www.rodart.it/news/hanno-scritto-di-rod.html">Hanno scritto di Rod�</a></h3><p>Citata da : Dino Maras&agrave; , Flavio De Gregorio , Anna Francesca Biondolillo , Elena Cicchetti , Vittoria Colpi ,... <a class="readon" href="http://www.rodart.it/news/hanno-scritto-di-rod.html">Leggi tutto...</a></p></div></div>		</div>
				<div class="moduletable_link">
							<h3>
					Link				</h3>
				<div class="flexcontent_link"><div class="flexcontentitem_link"><p><p><a href="http://www.viviarteviva.it/arteviva/" target="_blank">VIVIARTEVIVA</a></p><p><a href="http://www.google.it" target="_blank">GOOGLE </a></p><p><a href="http://www.campingmaggiolino.it/" target="_blank">CAMPING IL MAGGIOLINO</a></p><p><a href="http://www.premiocolomba.com" target="_blank">PREMIO COLOMBA<br /></a></p><p><a href="http://www.agrigentoarte.it/" target="_blank">AGRIGENTO ARTE<br /></a></p><p><a href="http://www.cdiffusionearte.com/" target="_blank">CENTRO DIFFUSIONE ARTE </a></p><p><a href="http://www.galleriazamenhof.com/index.html" target="_blank">GALLERIA ZAMENHOF</a> </p><p><a href="http://www.terrarubra.com/home.php?nav=curriculum" target="_blank">ALMA SEGES </a></p><p><a href="http://www.premioartelaguna.it/" target="_blank">PREMIO ARTE LAGUNA</a>  </p> </p></div></div>		</div>
								</div>
					</div>
				</div>
					</div>
		<div class="roda-footer">
					<div class="moduletable_random">
					</div>
				</div>	
	</div>
	<style>
		a#marchio, a#marchi:visited {
			color: #845231;
			font-size: 10px;
			 position: absolute;
    right: 10px;
    top: -20px;
		}			
		a#marchio:hover {
			color: #300;
			font-size: 10px;		
		}
	</style>
	<div class="fmarchio" >
		<a id="marchio" target="_blank" href="http://www.javanile.org/?track=1">powered by javanile.org</a>
	</div>
	<div style="text-align:justify;font-size:10px;padding:4px;float:right;">
		(c) Ro D'A 2012 - Questo sito web &egrave; di propriet&agrave; di RoD&apos;A.
		Si informa che &egrave; vietata qualsiasi riproduzione in pubblico totale o parziale fatta eccezione di un uso domestico o puramente informativo dei contenuti immagini è testi presenti nel sito www.rodart.it.
		Inoltre &egrave; vietata la riproduzione in qualsiasi forma o l'utilizzo anche parziale a fini commerciali.
		- <a href="https://www.google.com/analytics/web/?et=&authuser=#report/visitors-overview/" target="_blank">Statistiche</a>
			</div>
</body>
</html>
<!-- 1637527368 -->