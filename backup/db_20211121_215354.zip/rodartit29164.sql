-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: m-01.th.seeweb.it
-- Creato il: Nov 21, 2021 alle 22:24
-- Versione del server: 5.6.30-1~bpo8+1
-- Versione PHP: 7.2.34-28+0~20211119.67+debian9~1.gbpf24e81

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rodartit29164`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_banner`
--

CREATE TABLE `roda_banner` (
  `bid` int(11) NOT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'banner',
  `name` varchar(50) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_bannerclient`
--

CREATE TABLE `roda_bannerclient` (
  `cid` int(11) NOT NULL,
  `name` varchar(60) NOT NULL DEFAULT '',
  `contact` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_bannerfinish`
--

CREATE TABLE `roda_bannerfinish` (
  `bid` int(11) NOT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `impressions` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(50) NOT NULL DEFAULT '',
  `datestart` datetime DEFAULT NULL,
  `dateend` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_categories`
--

CREATE TABLE `roda_categories` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(100) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(10) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_categories`
--

INSERT INTO `roda_categories` (`id`, `parent_id`, `title`, `name`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'Pagine', 'Pagine', '', '1', 'left', '', 1, 62, '2011-11-08 01:33:22', NULL, 5, 0, 0, 'imagefolders=*2*'),
(2, 0, 'Pensieri', 'Pensieri', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, 'imagefolders=*2*'),
(3, 0, 'Le Opere', 'Le Opere', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, 'imagefolders=*2*'),
(4, 0, 'Recensioni', 'Recensioni', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, 'imagefolders=*2*'),
(5, 0, 'News', 'News', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, 'imagefolders=*2*'),
(6, 0, 'Rod\\\'A\\\'', 'Rod\\\'A\\\'', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(7, 0, 'Pagine Catalogo', 'Pagine Catalogo', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, 'imagefolders=*2*'),
(9, 0, 'Dicono di me', 'Dicono di me', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, 'imagefolders=*2*');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_components`
--

CREATE TABLE `roda_components` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `parent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_components`
--

INSERT INTO `roda_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`) VALUES
(1, 'Banner', '', 0, 0, '', 'Gestione banner', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, ''),
(2, 'Gestione banner', '', 0, 1, 'option=com_banners', 'Banner attivi', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, ''),
(3, 'Gestione clienti', '', 0, 1, 'option=com_banners&task=listclients', 'Gestione clienti', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, ''),
(4, 'Web link', 'option=com_weblinks', 0, 0, '', 'Gestione collegamenti web', 'com_weblinks', 0, 'js/ThemeOffice/globe2.png', 0, ''),
(5, 'Gestione web link', '', 0, 4, 'option=com_weblinks', 'Vedi collegamenti web esistenti', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, ''),
(6, 'Categorie web link', '', 0, 4, 'option=categories&section=com_weblinks', 'Gestione categorie collegamenti web', '', 2, 'js/ThemeOffice/categories.png', 0, ''),
(7, 'Contatti', 'option=com_contact', 0, 0, '', 'Modifica dettagli contatti', 'com_contact', 0, 'js/ThemeOffice/user.png', 1, ''),
(8, 'Gestione Contatti', '', 0, 7, 'option=com_contact', 'Modifica dettagli contatti', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, ''),
(9, 'Categorie contatti', '', 0, 7, 'option=categories&section=com_contact_details', 'Gestione categorie contatti', '', 2, 'js/ThemeOffice/categories.png', 1, ''),
(10, 'Prima pagina', 'option=com_frontpage', 0, 0, '', 'Gestione prima pagina', 'com_frontpage', 0, 'js/ThemeOffice/component.png', 1, ''),
(11, 'Sondaggi', 'option=com_poll', 0, 0, 'option=com_poll', 'Gestione sondaggi', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, ''),
(12, 'News feed', 'option=com_newsfeeds', 0, 0, '', 'Gestione news feed', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, ''),
(13, 'Gestione News feed', '', 0, 12, 'option=com_newsfeeds', 'Gestione news feed', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, ''),
(14, 'Gestione categorie', '', 0, 12, 'option=com_categories&section=com_newsfeeds', 'Gestione categorie', '', 2, 'js/ThemeOffice/categories.png', 0, ''),
(15, 'Login', 'option=com_login', 0, 0, '', '', 'com_login', 0, '', 1, ''),
(16, 'Cerca', 'option=com_search', 0, 0, '', '', 'com_search', 0, '', 1, ''),
(17, 'Syndicate', '', 0, 0, 'option=com_syndicate&hidemainmenu=1', 'Configurazione syndication', 'com_syndicate', 0, 'js/ThemeOffice/component.png', 0, ''),
(18, 'Mass Mail', '', 0, 0, 'option=com_massmail&hidemainmenu=1', 'Invia Mass Mail', 'com_massmail', 0, 'js/ThemeOffice/mass_email.png', 0, ''),
(19, 'JCE Admin', 'option=com_jce', 0, 0, 'option=com_jce', 'JCE Admin', 'com_jce', 0, 'js/ThemeOffice/component.png', 0, ''),
(20, 'JCE Configuration', '', 0, 19, 'option=com_jce&task=config', 'JCE Configuration', 'com_jce', 0, 'js/ThemeOffice/controlpanel.png', 0, ''),
(21, 'JCE Languages', '', 0, 19, 'option=com_jce&task=lang', 'JCE Languages', 'com_jce', 1, 'js/ThemeOffice/language.png', 0, ''),
(22, 'JCE Plugins', '', 0, 19, 'option=com_jce&task=showplugins', 'JCE Plugins', 'com_jce', 2, 'js/ThemeOffice/add_section.png', 0, ''),
(23, 'JCE Layout', '', 0, 19, 'option=com_jce&task=editlayout', 'JCE Layout', 'com_jce', 3, 'js/ThemeOffice/content.png', 0, ''),
(24, 'ARTIO JoomSEF', 'option=com_sef', 0, 0, 'option=com_sef', 'ARTIO JoomSEF', 'com_sef', 0, '../administrator/components/com_sef/images/icon.png', 0, '');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_contact_details`
--

CREATE TABLE `roda_contact_details` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `con_position` varchar(50) DEFAULT NULL,
  `address` text,
  `suburb` varchar(50) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `telephone` varchar(25) DEFAULT NULL,
  `fax` varchar(25) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(100) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(100) DEFAULT NULL,
  `default_con` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_contact_details`
--

INSERT INTO `roda_contact_details` (`id`, `name`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`) VALUES
(1, 'Rosalba D\'Arienzo', '', '', '', '', '', '', '', '', '', '', NULL, 'info.francescobianco@gmail.com', 0, 1, 0, '0000-00-00 00:00:00', 1, 'menu_image=-1\npageclass_sfx=\nprint=\nback_button=\nname=1\nposition=1\nemail=0\nstreet_address=1\nsuburb=1\nstate=1\ncountry=1\npostcode=1\ntelephone=1\nfax=1\nmisc=1\nimage=1\nvcard=0\nemail_description=1\nemail_description_text=\nemail_form=1\nemail_copy=0\ndrop_down=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=', 0, 6, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_content`
--

CREATE TABLE `roda_content` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `title_alias` varchar(100) NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `mask` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `catid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(100) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `parentid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_content`
--

INSERT INTO `roda_content` (`id`, `title`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`) VALUES
(1, 'Biografia', '', '<p>&nbsp;<img src=\"/images/stories/io.jpg\" alt=\" \" width=\"400\" height=\"300\" /></p><div>Rosalba D&#39;Arienzo in arte RoD&#39;A&#39;, nasce a Castelvetrano dove vive e lavora. Fin dalla tenera et&agrave; manifesta la sua forte passione per la pittura. Infatti essendo figlia d&#39;arte, poich&eacute; la mamma dipingeva e con il nonno paterno cugino di Gennaro Pardo illustre artista castelvetranese, Sente da subito l&#39;amore per l&#39;arte e per tutto ci&ograve; che &egrave; &quot;bello&quot;. Quindi si diploma all&#39;Accademia di Belle Arti di Palermo, e oltre ad essere un artista gi&agrave; affermata e conosciuta sia in Italia che all&#39;estero, &egrave; titolare di una gioielleria storica che fu del padre e che &egrave; anche il suo studio e atelier d&#39;arte. Le sue opere sono state recensite da autorevoli critici d&#39;arte e sono custodite in chiese, musei e in collezioni e raccolte private.&nbsp;Inoltre le sue opere sono state periziate con relazione di quotazione peritale redatta da Giancarlo Al&ugrave;.&nbsp;</div>', '', 1, 1, 0, 1, '2009-02-21 17:12:15', 62, '', '2013-06-20 21:38:14', 62, 62, '2013-06-20 21:38:14', '2009-02-21 17:09:07', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 13, 0, 7, 'biografia,vita,memoriale,profilo,ritratto', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice,biografia,vita,memoriale,profilo,ritratto', 0, 6999),
(3, 'Presentazione', '', '<p>E&#39; difficile presentare Rod&#39;A&#39; per quella poliedricit&agrave; e quella originalit&agrave; che contraddistinguono la sua arte.</p><p>Ma &egrave; sufficiente pensare a lei cos&igrave; com&#39;&egrave;, con li suo volto bello, solare, che parla gi&agrave; dell&#39;umanit&agrave; racchiusa nelle figure che dipinge, utilizzando spesso il rosso che esprime la sua passionalit&agrave;, e il nero il mistero, la profondit&agrave; del suo animo, ma anche il bianco e l&#39;oro, simbolo di purezza e di un romantico abbandono a una allegria di fanciulla, che si entusiasma con un candore che &egrave; propio del suo cuore.</p><p>Figure tragiche e comiche, figure nelle quali si incontrano mondi diversi, personaggi della mitologia greca o di varie etnie, intriganti, interessanti che attraggono come richiami sottili, silenziosi, come musica o poesia.</p><p>Rosalba o Rod&#39;A&#39; non si limita a ritrarre corpi, ma anime ricche interiormante e lei, cos&igrave; vogliosa e ricca di iniziativa, esprime tutto un universo di emozioni, sensazioni, conoscenze, cos&igrave; come i grandi artisti, ora come nel passato, hanno fatto, donando al pubblico che li ama, preziosi capolavori d&#39;arte.</p><p>Raffinata ed elegante, nella vita come nell&#39;arte, &egrave; nella spiritualit&agrave; e&nbsp; nell&#39;esistenziale che trova la linfa da cui trarre ispirazione.</p><p><em>Maria Rita Crifasi</em> </p>', '', 1, 1, 0, 1, '2009-03-01 18:00:53', 62, '', '2011-10-08 10:16:52', 62, 0, '0000-00-00 00:00:00', '2009-03-01 18:00:15', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 17, 0, 6, '', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice,presentazione di rod\'à', 0, 134),
(4, 'Galleria', 'Quadri', '{gallery}quadri{/gallery} ', '', 1, 2, 0, 3, '2009-03-01 18:30:21', 62, '', '2013-01-08 15:10:55', 62, 0, '0000-00-00 00:00:00', '2009-03-01 18:30:06', '0000-00-00 00:00:00', 'quadri/DSC01931copia.jpg|||0||bottom||\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/DSC01929copia.jpg|center||0||bottom||\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/DSC01940copia.jpg|||0||bottom||\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/darienzo_r.jpg|||0||bottom||\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/darienzo_r1.jpg|||0||bottom||\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/gorgone2.jpg\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/i_coralli_di_medusa.jpg\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/ragno.jpg\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/rossana.jpg\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/scarpe_rosse.jpg\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nquadri/vulcano1.jpg', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 50, 0, 1, 'galleria,foto,quadri,opere', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice,immagini quadri,foto opere,galleria', 0, 7242);
INSERT INTO `roda_content` (`id`, `title`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`) VALUES
(5, 'Recensioni', '', '<p><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>  </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" LatentStyleCount=\"156\">  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} </style> <![endif]--></p><!--[if gte mso 9]><xml>  <o:OfficeDocumentSettings>   <o:TargetScreenSize>800x600</o:TargetScreenSize>  </o:OfficeDocumentSettings> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:TrackMoves/>   <w:TrackFormatting/>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:DoNotPromoteQF/>   <w:LidThemeOther>IT</w:LidThemeOther>   <w:LidThemeAsian>X-NONE</w:LidThemeAsian>   <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>    <w:SplitPgBreakAndParaMark/>    <w:EnableOpenTypeKerning/>    <w:DontFlipMirrorIndents/>    <w:OverrideTableStyleHps/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>   <m:mathPr>    <m:mathFont m:val=\"Cambria Math\"/>    <m:brkBin m:val=\"before\"/>    <m:brkBinSub m:val=\"&#45;-\"/>    <m:smallFrac m:val=\"off\"/>    <m:dispDef/>    <m:lMargin m:val=\"0\"/>    <m:rMargin m:val=\"0\"/>    <m:defJc m:val=\"centerGroup\"/>    <m:wrapIndent m:val=\"1440\"/>    <m:intLim m:val=\"subSup\"/>    <m:naryLim m:val=\"undOvr\"/>   </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"   DefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"   LatentStyleCount=\"267\">   <w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\"/>   <w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\"/>   <w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\"/>   <w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\"/>   <w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\"/>   <w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Table Grid\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\"/>   <w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\"/>   <w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\"/>   <w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\"/>   <w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\"/>  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-priority:99; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\",\"serif\";} </style> <![endif]--><!--[if gte mso 9]><xml>  <o:OfficeDocumentSettings>   <o:TargetScreenSize>800x600</o:TargetScreenSize>  </o:OfficeDocumentSettings> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:TrackMoves/>   <w:TrackFormatting/>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:DoNotPromoteQF/>   <w:LidThemeOther>IT</w:LidThemeOther>   <w:LidThemeAsian>X-NONE</w:LidThemeAsian>   <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>    <w:SplitPgBreakAndParaMark/>    <w:EnableOpenTypeKerning/>    <w:DontFlipMirrorIndents/>    <w:OverrideTableStyleHps/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>   <m:mathPr>    <m:mathFont m:val=\"Cambria Math\"/>    <m:brkBin m:val=\"before\"/>    <m:brkBinSub m:val=\"&#45;-\"/>    <m:smallFrac m:val=\"off\"/>    <m:dispDef/>    <m:lMargin m:val=\"0\"/>    <m:rMargin m:val=\"0\"/>    <m:defJc m:val=\"centerGroup\"/>    <m:wrapIndent m:val=\"1440\"/>    <m:intLim m:val=\"subSup\"/>    <m:naryLim m:val=\"undOvr\"/>   </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"   DefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"   LatentStyleCount=\"267\">   <w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\"/>   <w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\"/>   <w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\"/>   <w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\"/>   <w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\"/>   <w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Normal (Web)\"/>   <w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Table Grid\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\"/>   <w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\"/>   <w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\"/>   <w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\"/>   <w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\"/>  </w:LatentStyles> </xml><![endif]--><!--[if !mso]><div   classid=\"clsid:38481807-CA0E-42D2-BF39-B33AF135CC4D\" id=ieooui></div> <style> st1\\:*{behavior:url(#ieooui) } </style> <![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-priority:99; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\",\"serif\";} </style> <![endif]--><p style=\"text-align: justify\" class=\"MsoNormal\" align=\"left\">{rdaddphp file=recensioni.php} </p><div align=\"left\">  </div><div align=\"left\">  </div><div align=\"left\">  </div><!--[if gte mso 9]><xml>  <o:OfficeDocumentSettings>   <o:TargetScreenSize>800x600</o:TargetScreenSize>  </o:OfficeDocumentSettings> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:TrackMoves/>   <w:TrackFormatting/>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:DoNotPromoteQF/>   <w:LidThemeOther>IT</w:LidThemeOther>   <w:LidThemeAsian>X-NONE</w:LidThemeAsian>   <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>    <w:SplitPgBreakAndParaMark/>    <w:EnableOpenTypeKerning/>    <w:DontFlipMirrorIndents/>    <w:OverrideTableStyleHps/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>   <m:mathPr>    <m:mathFont m:val=\"Cambria Math\"/>    <m:brkBin m:val=\"before\"/>    <m:brkBinSub m:val=\"&#45;-\"/>    <m:smallFrac m:val=\"off\"/>    <m:dispDef/>    <m:lMargin m:val=\"0\"/>    <m:rMargin m:val=\"0\"/>    <m:defJc m:val=\"centerGroup\"/>    <m:wrapIndent m:val=\"1440\"/>    <m:intLim m:val=\"subSup\"/>    <m:naryLim m:val=\"undOvr\"/>   </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"   DefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"   LatentStyleCount=\"267\">   <w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\"/>   <w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\"/>   <w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\"/>   <w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\"/>   <w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\"/>   <w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Normal (Web)\"/>   <w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Table Grid\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\"/>   <w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\"/>   <w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\"/>   <w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\"/>   <w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\"/>  </w:LatentStyles> </xml><![endif]--><!--[if !mso]><div   classid=\"clsid:38481807-CA0E-42D2-BF39-B33AF135CC4D\" id=ieooui></div> <style> st1\\:*{behavior:url(#ieooui) } </style> <![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-priority:99; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\",\"serif\";} </style> <![endif]--><div align=\"left\">  </div><div align=\"left\">  <!--[if gte mso 9]><xml>  <o:OfficeDocumentSettings>   <o:TargetScreenSize>800x600</o:TargetScreenSize>  </o:OfficeDocumentSettings> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:TrackMoves/>   <w:TrackFormatting/>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:DoNotPromoteQF/>   <w:LidThemeOther>IT</w:LidThemeOther>   <w:LidThemeAsian>X-NONE</w:LidThemeAsian>   <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>    <w:SplitPgBreakAndParaMark/>    <w:EnableOpenTypeKerning/>    <w:DontFlipMirrorIndents/>    <w:OverrideTableStyleHps/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>   <m:mathPr>    <m:mathFont m:val=\"Cambria Math\"/>    <m:brkBin m:val=\"before\"/>    <m:brkBinSub m:val=\"&#45;-\"/>    <m:smallFrac m:val=\"off\"/>    <m:dispDef/>    <m:lMargin m:val=\"0\"/>    <m:rMargin m:val=\"0\"/>    <m:defJc m:val=\"centerGroup\"/>    <m:wrapIndent m:val=\"1440\"/>    <m:intLim m:val=\"subSup\"/>    <m:naryLim m:val=\"undOvr\"/>   </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"   DefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"   LatentStyleCount=\"267\">   <w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\"/>   <w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\"/>   <w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\"/>   <w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\"/>   <w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\"/>   <w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Table Grid\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\"/>   <w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\"/>   <w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\"/>   <w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\"/>   <w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\"/>  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-priority:99; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\",\"serif\";} </style> <![endif]--><!--[if gte mso 9]><xml>  <o:OfficeDocumentSettings>   <o:TargetScreenSize>800x600</o:TargetScreenSize>  </o:OfficeDocumentSettings> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:TrackMoves/>   <w:TrackFormatting/>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:DoNotPromoteQF/>   <w:LidThemeOther>IT</w:LidThemeOther>   <w:LidThemeAsian>X-NONE</w:LidThemeAsian>   <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>    <w:SplitPgBreakAndParaMark/>    <w:EnableOpenTypeKerning/>    <w:DontFlipMirrorIndents/>    <w:OverrideTableStyleHps/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>   <m:mathPr>    <m:mathFont m:val=\"Cambria Math\"/>    <m:brkBin m:val=\"before\"/>    <m:brkBinSub m:val=\"&#45;-\"/>    <m:smallFrac m:val=\"off\"/>    <m:dispDef/>    <m:lMargin m:val=\"0\"/>    <m:rMargin m:val=\"0\"/>    <m:defJc m:val=\"centerGroup\"/>    <m:wrapIndent m:val=\"1440\"/>    <m:intLim m:val=\"subSup\"/>    <m:naryLim m:val=\"undOvr\"/>   </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"   DefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"   LatentStyleCount=\"267\">   <w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\"/>   <w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\"/>   <w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\"/>   <w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\"/>   <w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\"/>   <w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\"/>   <w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\"/>   <w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Table Grid\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\"/>   <w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\"/>   <w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\"/>   <w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\"/>   <w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\"/>   <w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\"/>   <w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\"/>   <w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\"/>   <w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"    UnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\"/>   <w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\"/>   <w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\"/>  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-priority:99; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\",\"serif\";} </style> <![endif]--></div>', '<p align=\"left\">&nbsp;<span style=\"font-size: 12pt; font-family: Arial\"><br /></span> </p><br /><p class=\"MsoNormal\" align=\"center\">&nbsp;</p> <p class=\"MsoNormal\" align=\"center\">&nbsp;</p>    <p class=\"MsoNormal\"><span style=\"font-family: Arial\">&nbsp;</span></p>   <span style=\"font-size: 12pt; font-family: Arial\"><br /></span><p align=\"left\"><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>  </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" LatentStyleCount=\"156\">  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} </style> <![endif]--><!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>  </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" LatentStyleCount=\"156\">  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} </style> <![endif]--></p>', 1, 1, 0, 1, '2009-03-01 18:32:52', 62, '', '2013-01-04 19:25:32', 62, 0, '0000-00-00 00:00:00', '2009-03-01 18:32:26', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 159, 0, 5, 'recensioni,commenti,critica,giudizi', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice,recensioni,commenti,critica,giudizi', 0, 6835);
INSERT INTO `roda_content` (`id`, `title`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`) VALUES
(13, 'Link', '', '<p><a href=\"http://www.viviarteviva.it/arteviva/\" target=\"_blank\">VIVIARTEVIVA</a></p><p><a href=\"http://www.google.it\" target=\"_blank\">GOOGLE </a></p><p><a href=\"http://www.campingmaggiolino.it/\" target=\"_blank\">CAMPING IL MAGGIOLINO</a></p><p><a href=\"http://www.premiocolomba.com\" target=\"_blank\">PREMIO COLOMBA<br /></a></p><p><a href=\"http://www.agrigentoarte.it/\" target=\"_blank\">AGRIGENTO ARTE<br /></a></p><p><a href=\"http://www.cdiffusionearte.com/\" target=\"_blank\">CENTRO DIFFUSIONE ARTE </a></p><p><a href=\"http://www.galleriazamenhof.com/index.html\" target=\"_blank\">GALLERIA ZAMENHOF</a> </p><p><a href=\"http://www.terrarubra.com/home.php?nav=curriculum\" target=\"_blank\">ALMA SEGES </a></p><p><a href=\"http://www.premioartelaguna.it/\" target=\"_blank\">PREMIO ARTE LAGUNA</a>  </p> ', '', 1, 1, 0, 1, '2009-03-28 15:20:02', 62, '', '2013-01-08 15:43:50', 62, 0, '0000-00-00 00:00:00', '2009-03-28 15:17:55', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 38, 0, 4, '', 'Rosalba D\'Arienzo - ROD\'A\' - artista - pittrice - decoratrice ', 0, 1305),
(14, 'Archivio Notizie', '', '{rdaddphp file=archivionotizie.php}', '', 1, 1, 0, 1, '2009-03-28 15:54:00', 62, '', '2011-11-08 01:53:34', 62, 0, '0000-00-00 00:00:00', '2009-03-28 15:53:17', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 7, 0, 3, 'notizie,info,news', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice,notizie,info,news ', 0, 5916),
(15, 'Vetri', '', '<p>{rdaddphp file=menucatalogo.php}</p><p>{gallery}pagina1{/gallery} </p>', '', 1, 2, 0, 7, '2009-03-28 16:14:09', 62, '', '2010-03-18 17:43:55', 62, 62, '2013-01-08 15:45:41', '2009-03-28 16:12:50', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 7, 0, 1, '', 'Rosalba D\'Arienzo,ROD\'A\',artista,pittrice,decoratrice', 0, 1409),
(21, '404', '404', '<!--[if gte mso 9]><xml>  <w:WordDocument>   <w:View>Normal</w:View>   <w:Zoom>0</w:Zoom>   <w:HyphenationZone>14</w:HyphenationZone>   <w:PunctuationKerning/>   <w:ValidateAgainstSchemas/>   <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>   <w:IgnoreMixedContent>false</w:IgnoreMixedContent>   <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>   <w:Compatibility>    <w:BreakWrappedTables/>    <w:SnapToGridInCell/>    <w:WrapTextWithPunct/>    <w:UseAsianBreakRules/>    <w:DontGrowAutofit/>   </w:Compatibility>   <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>  </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:LatentStyles DefLockedState=\"false\" LatentStyleCount=\"156\">  </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <style>  /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:\"Tabella normale\"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:\"\"; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:\"Times New Roman\"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} </style> <![endif]--><p align=\"center\">CARATTERISTICHE QUADRI </p><p align=\"center\">1 </p><p align=\"center\">&nbsp;titolo : MEDUSA</p><p align=\"center\">&nbsp;tecnica : MISTA</p><p align=\"center\">&nbsp; misura : cm 50x70 &nbsp; </p><p align=\"center\">2 </p><p align=\"center\">MEDUSA 2</p><p align=\"center\">&nbsp;&nbsp; ACRILICO</p><p align=\"center\">&nbsp;cm 40x80 </p><p align=\"center\">3 </p><p align=\"center\">&nbsp;NASCITA DEL CORALLO</p><p align=\"center\">&nbsp;ACRILICO SU TELA</p><p align=\"center\">cm 50X100</p><p align=\"center\">4</p><p align=\"center\">PALCOSCENICO</p><p align=\"center\">MISTA</p><p align=\"center\">cm 50X70</p><p align=\"center\">5</p><p align=\"center\">ANGELO METROPOLITANO</p><p align=\"center\">ACRILICO SU TELA</p><p align=\"center\">cm 50X70&nbsp; </p><p align=\"center\">6</p><p align=\"center\">LIBRO 1</p><p align=\"center\">MISTA SU TELA</p><p align=\"center\">cm 60X80</p><p align=\"center\">7</p><p align=\"center\">LIBRO 2</p><p align=\"center\">MATERICA MISTA CON GARZE</p><p align=\"center\">cm&nbsp;</p><p align=\"center\">8</p><p align=\"center\">LIBRI</p><p align=\"center\">MISTA</p><p align=\"center\">cm60X60 </p><p align=\"center\">9</p><p align=\"center\">INCONTRIAMOLI IN VOLO</p><p align=\"center\">ACRILICO SU TELA</p><p align=\"center\">cm</p><p align=\"center\">10</p><p align=\"center\">L&#39;URLO SILENZIOSO DI MEDUSA</p><p align=\"center\">MATERICA - MISTA SU TELA CON 8 CERNIERE LAMPO </p><p align=\"center\">cm 60X60 </p><p align=\"center\">11</p><p align=\"center\">1000 PETALI ROSSI</p><p align=\"center\">MATERICA - MISTA SU TELA </p><p align=\"center\">cm 40X60</p><p align=\"center\">12</p><p align=\"center\">SENZA TITOLO</p><p align=\"center\">13</p><p align=\"center\">INSTABILITA&#39;</p><p align=\"center\">MATERICA - MISTA SU TELA</p><p align=\"center\">cm 70 X 100</p><p align=\"center\">14</p><p align=\"center\">STRAPPI</p><p align=\"center\">MISTA SU TELA</p><p align=\"center\">cm 100X100</p><p align=\"center\">15</p><p align=\"center\">SI PUO&#39; ....</p><p align=\"center\">MATERICA - MISTA SU TELA</p><p align=\"center\">cm 50X60</p><p align=\"center\">16</p><p align=\"center\">ROSSANA</p><p align=\"center\">ACRILICO SU TELA</p><p align=\"center\">cm50X70</p><p align=\"center\">17</p><p align=\"center\">SCARPE ROSSE</p><p align=\"center\">ACRILICO</p><p align=\"center\">cm 60 X 60</p><p align=\"center\">18&nbsp; </p><p align=\"center\">FARFALLA</p><p align=\"center\">ACRILICO SU TELA&nbsp;</p><p align=\"center\">cm 60X60</p><p align=\"center\">19&nbsp; </p><p align=\"center\">I CORALLI DI MEDUSA </p><p align=\"center\">MISTA </p><p align=\"center\">cm 40X40</p><p align=\"center\">20&nbsp;</p><p align=\"center\">CORALLINO</p><p align=\"center\">MISTA</p><p align=\"center\"> cm 40X40</p><p align=\"center\">21</p><p align=\"center\">GORGONE</p><p align=\"center\">ACRILICO</p><p align=\"center\">cm 50X100</p><p align=\"center\">22</p><p align=\"center\">FRAMMENTI 1</p><p align=\"center\">MISTA SU TELA</p><p align=\"center\">cm 50X50</p><p align=\"center\">23</p><p align=\"center\">FRAMMENTI 2</p><p align=\"center\">MISTA SU TELA&nbsp;</p><p align=\"center\">cm 50X50</p><p align=\"center\">24</p><p align=\"center\">FRAMMENTI 3</p><p align=\"center\">MISTA SU TELA&nbsp;</p><p align=\"center\">cm 50X50</p><p align=\"center\">25</p><p align=\"center\">VULCANO</p><p align=\"center\">MATERICA - MISTA SU TELA</p><p align=\"center\">cm 50X50</p><p align=\"center\">26</p><p align=\"center\">FANTASIA</p><p align=\"center\">ACRILICO</p><p align=\"center\">cm 40X40</p><p align=\"center\">27</p><p align=\"center\">L&#39;ARCO E LA FRECCIA</p><p align=\"center\">ACRILICO</p><p align=\"center\">cm</p><p align=\"center\">28</p><p align=\"center\">TOTEM</p><p align=\"center\">ACRILICO SU TELA</p><p align=\"center\">cm</p><p align=\"center\">29</p><p align=\"center\">RAGNATELA</p><p align=\"center\">MATERICA - MISTA CON CHIODI E GARZE</p><p align=\"center\">cm</p><p align=\"center\">33 - 34 </p><p align=\"center\">IL NULLA</p><p align=\"center\">ACRILICO SU TELA - ACRILICO SU LEGNO</p><p align=\"center\">cm 40X80 - 64X91 </p>', '', 1, 0, 0, 0, '2004-11-11 12:44:38', 62, '', '2011-10-07 15:50:03', 62, 62, '2013-01-11 22:35:37', '2004-10-17 00:00:00', '0000-00-00 00:00:00', '', '', 'menu_image=-1\nitem_title=0\npageclass_sfx=\nback_button=\nrating=0\nauthor=0\ncreatedate=0\nmodifydate=0\npdf=0\nprint=0\nemail=0', 1, 0, 0, '', '', 0, 25960),
(20, 'Hanno scritto di Rodà', '', '<p class=\"MsoNormal\"><span style=\"font-size: 16pt; font-family: &quot;Eras Medium ITC&quot;\">Citata da :<span> </span>Dino Maras&agrave; , Flavio De Gregorio , Anna Francesca Biondolillo , Elena Cicchetti , Vittoria Colpi , Paolo Levi ,<span> </span>Nadine Giove, Daniele Radini Tedeschi<br /></span></p>', '', 1, 1, 0, 5, '2010-11-28 20:52:01', 62, '', '2013-01-11 21:13:19', 62, 0, '0000-00-00 00:00:00', '2010-11-28 20:50:56', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 1, '', '', 0, 4927),
(28, 'Nadine Giove', '', '<p>L&#39;arte piena e voluttuosa di Rosalba D&#39;Arienzo comunica prima di tutto una grande passione per la pittura, che si estrinseca in opere esteticamente valide. L&#39;iper-decorativismo e il preziosismo coloristico dei suoi dipinti, tuttavia, nulla tolgono alla loro profondit&agrave;. Le pennellate vigorose dal colore caldo e avvolgente sottolineano la sensualit&agrave; dei volti, la loro umana espressivit&agrave;. Tali volti sono in realt&agrave; delle maschere e tuttavia esse posseggono l&#39;energia vitale dei soggetti reali. Sono spesso volti femminili, colmi di mistero, che, come moderne sfingi, suscitano inquietanti interrogativi e si svelano solo all&#39;osservatore meno distratto del nostro tempo. Davanti ad un&#39;opera dell&#39;artista, per concludere, si rimane ipnotizzati in una sorta d&#39;incantato stupore, e si ha sovente l&#39;impressione di non aver guardato mai abbastanza, di non aver compreso appieno il suo significato pi&ugrave; profondo. Rosalba D&#39;Arienzo crea un&#39;arte dai significati universali, che riesce ad ammaliare lo spettatore e a trasportarlo in un mondo magico.</p><p align=\"right\">Nadine Giove </p>', '', 1, 1, 0, 4, '2013-01-04 19:26:50', 62, '', '2013-03-04 09:37:18', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:26:08', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 4, '', '', 0, 3167),
(29, 'Daniele Radini Tedeschi', '', '<p>Nella sua vasta produzione possiamo incontrare quadri appellabili monocromi, simili cio&egrave; alle grandi tele dipinte da Mario Schifano negli anni &#39;60; Oppure opere aventi linee, segmenti e rette che, in una fusione talvolta a fasce, talvolta a croci esprimono dinamismo, forza e energia.</p><p align=\"right\">Daniele Radini Tedeschi </p>', '', 1, 1, 0, 4, '2013-01-04 19:28:08', 62, '', '2013-01-11 22:31:23', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:27:32', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 3, 0, 3, '', '', 0, 3299),
(32, 'Il rosso e il nero RoD\'A\'', '', '<p>Il laboratorio di Rosalba D&#39;Arienzo in arte RoD&#39;A&#39; palpita di vita e di colori. Le sue creazioni artistiche, esprimono l&#39;universo femminile in piena trasformazione e liberano campi di energia nelle delicatezze cromatiche degli oggetti che decora personalmente, passione e temperamento nei quadri che dipinge. Il rosso e il nero sono i colori prevalenti delle sue tele, i cui i sogetti sono spesso volti di donne colte in frammenti di esistenza e di sogno. Il rosso: corpo e materia, fuoco ed amore che divampano, eleganza e sensualit&agrave; di un tango argentino, di una rosa voluttuosa. Il nero: ombre di solitudine, spiritualit&agrave; e silenzio, morbidi occhi neri, fecondi di emozioni e di sorprese. La consapevolezza del s&egrave; femminile, l&#39;empatia e la comunanza di affetti che legano tra loro le donne, sono l&#39;humus di questa volitiva artista castelvetranese su cui, germogliano facilmente intuizione e creativit&agrave;, proiettate con sentire profondo nell&#39;unicit&agrave; dei colori e nell&#39;esaltazione del mondo interiore.</p><p align=\"right\">Maria Antonietta Garofalo </p>', '', 1, 1, 0, 9, '2013-02-15 17:19:42', 62, '', '2013-03-04 09:28:17', 62, 0, '0000-00-00 00:00:00', '2013-02-15 17:09:08', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 3, 0, 2, '', '', 0, 2350),
(33, 'Nota critica a Rosalba D\'Arienzo (RoD\'A\')', '', '<p>Le opere di Rosalba, esprimono appieno i grandi temi esistenziali che attraversano il nostro tempo. All&#39;osservatore meno attento i suoi quadri potrebbero sembrare dei riuscitissimi giochi di cromie, coniugati ad una tecnica molto accurata, ma solo riuscendo a penetrarli possiamo coglierne il pieno significato, essi hanno qualcosa da dire, soltanto a chi &egrave; preposto a porsi delle domande, rimangono muti a chi non &egrave; in grado di abbandonare una visione razionale. Rosalba &egrave; un essere determinato, sa di trovarsi in una posizione geografica svantaggiata, rispetto alle grandi correnti culturali artistiche delle grandi citt&agrave; europee, ma sa di esistere, e, non soltanto &egrave; cosciente della sua esistenza, ma vuole anche mutarla, attraverso la ricerca del bello interiore, che possa appagare questo vuoto, dovuto soprattutto all&#39;inerzia del contesto artistico e ideologico in cui vive. Attraverso l&#39;opera d&#39;arte, cio&egrave; nel bisogno pittorico, Rosalba, esprime la sua piena passionalit&agrave;, l&#39;adempimento reale dei suoi desideri; l&#39;illusione attraverso le sue opere, ora, si trasforma in realt&agrave; che pu&ograve; essere toccata con mano e percepita visivamente. Davanti ad una sua tela, &egrave; quasi impossibile restare indifferenti, insensibili. Il nostro inconscio riemerge in maniera cos&igrave; prepotente, da farci percepire tutta la nostra condizione esistenziale, la sua arte riesce ad evocare le nostre suggestioni pi&ugrave; profonde. L&#39;impasto dei colori, in cui prevalgono sfumature di neri e rossi, non sono mai casuali, risultano sempre penetranti, sempre attivi, vorticano incessantemente in una continua lotta stimolante, che invade l&#39;organismo, riuscendo percettivamente a creare sempre delle condizioni visive altamente dinamiche, da tensioni che esplodono in maniera multidirezionale. Il nero da condizione psicologica ancestrale, lugubre, acquista dimensioni e significati opposti, diventa l&#39;infinito, il viaggio alla ricerca del nostro esistere, la condizione primordiale, la vita. Il rosso nelle sue tonalit&agrave;, ricerca aspetti coniuganti classici, calati con l&#39;antica cultura siceliota, richiami di paesaggi, di miti, di quotidiana esistenza, ora rimandi della cultura ellenica, ora alla descrizione intima dell&#39;incostanza del pianeta. Rosalba &egrave; costantemente alla ricerca del bello interiore, e, le sue opere pur altamente dinamiche, vogliono sempre significare una condizione d&#39;amore, di pace attraverso una elaborata ricerca cromatica, coniugata dal sapiente uso di poche cromie (nero, rosso, bianco, tocchi aurei), che esprimono appieno il suo travaglio interiore, alle vicissitudini di vita, al mondo, alla quotidiana esistenza. La sua preparazione accademica, ha portato l&#39;artista ad essere estremamente duttile, ed a sapersi mostrare, sia attraverso l&#39;espressione di temi classici, naturalmente trasfusi nella personalissima maniera, sia nell&#39;informalit&agrave;, dove riesce ad esprimere appieno tutta la sua carica emotiva. Seppur travagliata intimamente, Rosalba &egrave; sicura che la bellezza, il bello, &egrave; la primaria condizione di vita, la salvifica verit&agrave; cosmica, e le sue tele seppur intimamente travagliate, vogliono sempre esprimere questa primaria teoria. Jos&egrave; Jim&egrave;nez scrive &quot;Perch&egrave; il viaggio vero e propio deve essere fatto da ogniuno. L&#39;esperienza artistica &egrave; qualcosa di totalmente individuale, come l&#39;amore o la solitudine. Una freccia che l&#39;individuo scaglia mettendo in pratica una proposta, e che arriva al suo obbiettivo solo se alcuni dei suoi significati raggiungono un altro individuo, che si appropria di essi e li ricrea. Solo allora il colpo v&agrave; a bersaglio.&quot; Rosalba scagliando la sua freccia punta al cuore di ogni individuo, e riesce, attraverso la sua impronta ad indurlo alla meditazione, quindi a riconsiderare la sua piena esistenza, la sua stessa vita.</p><p align=\"right\">Giacomo Sciaccotta&nbsp; </p>', '', 1, 1, 0, 9, '2013-02-15 17:26:53', 62, '', '2013-03-04 09:47:55', 62, 0, '0000-00-00 00:00:00', '2013-02-15 17:19:54', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 1, '', '', 0, 2424),
(34, 'Dicono di me', '', '{rdaddphp file=diconodime.php} ', '', 1, 1, 0, 1, '2013-02-20 21:06:22', 62, '', '2013-02-20 21:11:02', 62, 0, '0000-00-00 00:00:00', '2013-02-20 21:05:56', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 2, 0, 1, '', '', 0, 3762),
(35, 'Sandro Serradifalco', '', '<div>Arte poliedrica ed originale quella della D&#39;Arienzo, dove la potenza del colore esprime la profondit&agrave; delle sue emozioni. Nell&#39;opera &quot;Frammenti 1&quot; , vediamo un volto di donna, una maschera, caratterizzata dal forte contrasto tra il bianco, simbolo di purezza e il nero, simbolo di mistero, da cui &nbsp;scaturiscono frammenti rossi, simbolo di una passione. Passione che nulla vale senza l&#39;amore, simboleggiato dal cuore racchiuso nella bolla di vetro. Un sentire romantico dove volti e scenari si arricchiscono di palpabile lirismo. L&#39;artista condivide con l&#39;osservatore la propria indagine intima, che declina il suo essere donna tra vulnerabilit&agrave; e forza, ma senza paura di confrontarsi con i lati pi&ugrave; oscuri e problematici del suo animo. &nbsp;</div><div style=\"text-align: right\">Sandro Serradifalco</div>', '', 1, 1, 0, 4, '2013-05-30 20:05:00', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2013-05-30 20:00:52', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 1, 0, 2, '', '', 0, 2233),
(36, 'Giancarlo Alù', '', '<div>La pittura di Rosalba D&#39;Arienzo pu&ograve; essere definita potente ed evocativa delle cromie. &nbsp;Il lavoro sulla percezione dei colori e dei volumi legati al linguaggio espressivo astratto sfociano nell&#39;armonica realizzazione delle sue opere. Le evoluzioni cromatiche dell&#39;Artista Rosalba D&#39;Arienzo sono vortici immaginari del flusso dei suoi pensieri. Sono questi che guidano la mano dell&#39;Artista nella stesura narrativa, mischiandosi all&#39;istinto e alla creativit&agrave;. Ci troviamo davanti ad una pittura d&#39;impatto, spontanea, risultato di una libera ricerca di nuovi elementi espressivi caratterizzati da eleganza sintattica e formale. La pittrice Rosalba D&#39;Arienzo sa attrarre l&#39;attenzione di critici e collezionisti in ambito mondiale.</div><div style=\"text-align: right\">&nbsp;Giancarlo Al&ugrave;</div>', '', 1, 1, 0, 4, '2013-05-30 20:06:54', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2013-05-30 20:05:18', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 1, 0, 1, '', '', 0, 2108),
(22, 'Dino  Marasà', '', 'L&lsquo;excursus artistico di Rosalba D&lsquo;Arienzo ci regala diversi lavori, ma tutti accomunati dall&rsquo; amore per il colore. Questo &egrave; infatti il narratore prediletto del suo racconto. Parole fatte di cromatismi e frasi enfatizzate da ampie campiture che ci inducono, ben volentieri, ad una rivisitazione dello stesso nostro modo di vedere le cose. Siano figure mitologiche o elementi della natura, le sue espressioni artistiche svelano una personalit&agrave; complessa, che riflette e rielabora assumendosi obiettivi che a prima vista sembrano difficili da raggiungere, ma che vengono addirittura superati. Quindi la grandezza pittorica di Rosalba D&rsquo;Arienzo &egrave; ravvisabile non soltanto sulla sua tela e nel suo pennello ma anche nel suo modo di affrontare la stessa ricerca artistica. Le sue realizzazioni giustamente posseggono un tono di solennit&agrave; come il silenzio che incornicia la meditazione e l&lsquo;inventiva, qualit&agrave; proprie di questa brava pittrice.<br /><div align=\"right\">&nbsp;</div><div align=\"right\">Dino&nbsp; Maras&agrave;</div><p>&nbsp;</p><p>  L&#39;imbastitura cromatica e significativa del reso pittorico di Rosalba D&#39;Arienzo instaura un dialogo diretto con il fruitore, coinvolgendolo in una narrazione fatta da simboli iconici delle umane passioni. Rossi vivaci e stimolanti dominano assieme al nero stimolando la passionalit&agrave; e il senso di mistero innati nell&#39;uomo. Un&#39;arte che riesce a dosare sensualit&agrave; e raffinatezza e che invoglia il fruitore ad una visione d&#39;insieme pi&ugrave; spensierata.</p><div align=\"right\">&nbsp;</div><div align=\"right\">Dino&nbsp; Maras&agrave;</div>', '', 1, 1, 0, 4, '2013-01-04 19:19:26', 62, '', '2013-04-18 02:48:41', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:18:46', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 5, 0, 10, '', '', 0, 2538),
(23, 'Flavio De Gregorio', '', 'La figura e il condiviso rapporto essenziale con essa, la descrittiva e reattiva sinuosit&agrave; convergono verso il rientro schematico dell&rsquo;opera pittorica dell&rsquo;Artista D&rsquo;Arienzo Rosalba &ldquo; RoD&rsquo;A&rsquo; &ldquo;, in una fase relativa alla trasfigurazione del circostante naturalistico in sintesi alla condizione emblematica resa tale dall&lsquo;oggettivit&agrave; proposta dalla pittrice &ldquo; RoD&rsquo;A&rsquo; &ldquo; e che, nel soggetto diviene essenza e purezza di una forma dalla quale : resta vivo il senso della vita in un sentimento che regna e palpita per dinamicit&agrave; nel modello riassuntivo. In tale contesto estetico, il dipinto di D&rsquo;Arienzo Rosalba &ldquo; RoD&rsquo;A&rsquo; &ldquo;, promuove per tangibile storicit&agrave;, atta a condizionare il concretismo estetico, l&lsquo;intrinseca visione per la quale, il divenire nella stimata contesa vitalit&agrave;, espleta l&lsquo;azione regressa nel contesto, del soave rapporto iconologico e formula l&rsquo;effetto reattivo della ben gestita conservazione in sintesi alla frammentata verosimiglianza, dove, la dispersione lineare modera il suggestivo programma riflesso e predispone le intersezioni spazialiste, per i cui settori in ombra, l&rsquo;oggetto posto in primo piano differisce dalla dettata disposizione segnica e contribuisce a realizzare il solido disposto iconografico, graficamente proiettato verso un fondo dove, l&rsquo;illusione avverte la percettiva liricit&agrave; progressiva e recepisce attraverso sensazioni e impulsi la traiettoria silente nell&rsquo;espressivit&agrave;.. di una visione concreta, sfaccettata nella sostenuta modulazione cromatica che, posta in rilievo della stessa intuizione, espleta la funzione imitativa per un&lsquo;elegante e decorosa ricostruzione di una transazione avvenuta e ricca di virtuosi accostamenti tonali, proposti per il meraviglioso ritorno del simbolico e orientativo messaggio.<br /><br /><div align=\"right\">Flavio De Gregorio</div><div align=\"right\">&nbsp;</div><div align=\"left\">&nbsp;</div><div align=\"left\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *&nbsp; *&nbsp; * </div><div align=\"left\">&nbsp;</div><div align=\"left\">Con viva partecipazione intrinseca, la pittrice D&#39;Arienzo Rosalba, nota anche con lo pseudonimo di Rod&#39;&agrave;, contribuisce ad infondere grandi emozioni per via del frequente uso di cromie vivaci gi&agrave; avvertite prima dello stesso attimo percettivo attinente all&#39;illusivo moto di ricerca. Cos&igrave; che il dipinto vivo e ricco di tonalit&agrave; prevalentemente rosse che vengono impresse dalla pittrice Rosalba D&#39;Arienzo, prosegue in un sussulto estetico di interesse notevole e si colma di effetti concretamente riassuntivi nell&#39;ambito di una visione naturalistica universale dove, la terra, l&#39;acqua, il cielo e il fuoco, vengono presentati con reattivo condizionamento emotivo e in sintesi a sfondo espressionista da nobile figura consona al richiamo nostalgico della stessa autrice.</div><div align=\"left\">&nbsp;</div><div align=\"right\">Flavio De Gregorio <br /></div>', '', 1, 1, 0, 4, '2013-01-04 19:20:40', 62, '', '2013-03-04 09:49:48', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:19:58', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 9, '', '', 0, 4378),
(31, 'Oltre il tempo, oltre il colore, oltre...', '', '<p>La pittura di Rosalba D&#39;Arienzo si libera da ogni contorno, per viaggiare nei meandri della fantasia, ed esprimere le pulsioni e le vibrazioni pi&ugrave; sottili dell&#39;animo. Attraverso l&#39;originalit&agrave; del disegno e del colore emergono temi profondi, forme sublimi, ricche di simboli e di significati nascosti, un mondo mitologico, di figure eteree, delicate, che trascina nella dimensione di un immaginario popolato da segni particolari, sensazioni raffinate, elementi estetici curati nel particolare. La maschera e l&#39;occhio su un libro aperto dal quale trascendono parole antiche, indicano la sete di penetrare il mistero stesso del libro, di penetrare la conoscenza racchiusa nelle parole, il senso nascosto che trasuda da ogni linea. La sinuosit&agrave; e la regalit&agrave; del serpente, avvolto al viso della Gorgone e alla tela, la passionalit&agrave; dei colori forti come il rosso, il bianco e il nero, e poi la fuga verso i colori pastello dei paesaggi nebbiosi, malinconici, che richiamano la laguna veneziana, gli stucchi veneziani, o la malinconia di pulcinella in un viso bello e profondo, lo stato d&#39;animo, dunque, che si fa tangibile e si traduce in forme, espressioni, trasparenze, luce. L&#39;inquietudine del vivere, il mistero insondabile che ci sovrasta e ci regala note dolcemente malinconiche, e alla fine quella pacatezza serena, esplosioni di fasci di luce e prorompenti coralli, traduzione di quell&#39;attaccamento alla vita e alla gioia del vivere che diventa gusto estetico, ricerca del bello, nutrimento dello spirito e dell&#39;occhio fermo ad osservare, a cogliere... Un sentire intenso, mai fermo in superficie, ma teso verso labirinti, abissi di conoscenza, di ricerca, di risposte. Il senso della vita e delle cose, l&#39;ansia di valicare confini, andare oltre, liberi da limiti angusti, spaziando in un mondo di romantiche emozioni.</p><p align=\"right\">&nbsp;Maria Rita Crifasi </p>', '', 1, 1, 0, 9, '2013-02-15 17:06:23', 62, '', '2013-03-04 09:19:54', 62, 62, '2013-04-18 03:21:58', '2013-02-15 16:35:16', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 3, '', '', 0, 2243),
(24, 'Anna Francesca Biondolillo', '', '<p>Pittura dettata da intime riflessioni del proprio sentire del suo essere donna, rielaborate attraverso una tecnica personalizzata ed uno stile che richiama con piacere il gusto surreale. Dipinti che sgorgano da meandri misteriosi da cui l&rsquo;artista d&agrave; prova di&nbsp; straordinaria fantasia e nello stesso tempo di grande maestria nel comunicare il suo messaggio. Le maschere di Rosalba D&rsquo; Arienzo in Arte &ldquo;RoD&rsquo; A&rsquo;&rdquo; raffigurano i vari aspetti dello stato d&rsquo;animo della donna: ora vulcanica e passionale, a volte enigmatica e misteriosa, in ogni caso ci coinvolgono per le lumeggianti visioni dalla tavolozza vivace e accesa, rendendoci partecipe di vivere realt&agrave; sublimate dall&rsquo;estro di si grande talento pittorico.</p><p align=\"right\">Anna Francesca Biondolillo</p>', '', 1, 1, 0, 4, '2013-01-04 19:21:45', 62, '', '2013-01-11 22:17:44', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:21:13', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 8, '', '', 0, 3372),
(25, 'Elena Cicchetti', '', '<p>E&rsquo; nelle immagini e nei colori che la pittrice riesce a cogliere la parte migliore della sua pittura.La sua arte e i colori che usa sono l&rsquo;espressione dei vari momenti che esprimono l&rsquo;io buono interiore dell&rsquo;artista, e sono i colori che riflettono una ricerca cromatica, laddove fusi insieme risultano sobri ed eleganti in un insieme caldo e vaporoso nello stesso tempo. Con le sue opere Rosalba ci fa fare sogni fantastici, che ci portano a riflettere e sognare. Il colore &egrave; importante perch&eacute; &egrave; con esso che si rappresenta la passione dell&rsquo;essere, anzi dei personaggi. Le linee si mescolano con i colori con tratti decisi dando origine al proprio ruolo.</p><p align=\"right\">&nbsp;Elena Cicchetti </p>', '', 1, 1, 0, 4, '2013-01-04 19:22:38', 62, '', '2013-01-11 22:20:18', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:22:09', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 3, 0, 7, '', '', 0, 4278),
(26, 'Vittoria Colpi', '', '<p>Rosalba D&rsquo; Arienzo si esprime in pittura in modo sciolto, con campiture di accesi cromatismi. Il suo universo pittorico &egrave; plasmato da un profondo desiderio di evidenziare il bello, confinando il pi&ugrave; possibile il male e la sofferenza. Volti e maschere che l&rsquo;artista crea di certo non nascondono un&rsquo;inquietudine del vivere, ma l&rsquo;eleganza delle fisionomie, gli occhi dilatati, il candore del viso, le labbra rosse e carnose s&rsquo;impongono in positivo sulla tela con stupefatta ingenuit&agrave;. Cos&igrave; nelle opere &ldquo;Frammenti 1&rdquo;, &ldquo;Vulcano&rdquo;, e ne &rdquo;I Coralli di Medusa&rdquo;, di matrice surrealista. Proprio la ricercata e surreale sensualit&agrave;, che emerge intensa in &ldquo;Scarpe rosse&rdquo;, suggella lo stile personale ed imprevedibile di RoD&rsquo;A&rsquo;.</p><p align=\"right\">Vittoria Colpi </p>', '', 1, 1, 0, 4, '2013-01-04 19:23:48', 62, '', '2013-01-11 22:23:26', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:23:18', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 4, 0, 6, '', '', 0, 3284),
(27, 'Paolo Levi', '', '<p>Tonalit&agrave; forti e vibranti si traducono quali simboli di vitalit&agrave; ed energia nell&rsquo;arte di Rosalba D&rsquo;Arienzo. Partendo da un impianto rievocativo di elementi tratti dalla natura, l&rsquo;artista ne astrattizza i profili, sia che si tratti di inflorescenze marine o di fantasmagorie stellari. Il segno &egrave; denso e deciso, a volte quasi violento nella sua incisivit&agrave;. La pittrice pone particolare attenzione agli effetti luminosi, creando sfumature e punti di luce sulla tela che attirano lo sguardo dell&rsquo;osservatore con la loro esuberanza. Dal punto di vista tecnico D&rsquo;Arienzo spazia dall&rsquo;uso degli acrilici alla tecnica Polimaterica, raggiungendo sempre risultati di energica espressivit&agrave;. Queste opere hanno in s&eacute; un qualcosa di prezioso, sia nella scelta dei soggetti che dei cromatismi, capaci di trasmettere l&rsquo;essenza pi&ugrave; intima dei soggetti rappresentati, che viene tradotta sulla tela con impeto incontenibile.</p><p align=\"right\">Paolo Levi</p>', '', 1, 1, 0, 4, '2013-01-04 19:24:40', 62, '', '2013-03-04 09:35:48', 62, 0, '0000-00-00 00:00:00', '2013-01-04 19:24:08', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 3, 0, 5, '', '', 0, 3280),
(30, 'Curriculum', '', '<p><strong>2008</strong></p><ul><li>Collettiva &ldquo;Libro Opera D&#39;Arte&rdquo; - Lingotto Fiere &ndash; Sala Avorio &ndash; 8Gallery</li><li>Collettiva Arte &egrave;e Artigianato al Femminile &ndash; FIDAPA &ndash; Castelvetrano<br /></li><li>Collettiva &ldquo;Donne in Arte&rdquo; Vivi Arte Viva &ndash; Torino</li></ul><br /><strong>2009<br /></strong><ul><li>Collettiva 3&deg; Premio Internazione Bo&egrave; &ndash; Il Tempio &ndash; Palermo</li><li>Collettiva &ldquo;Inseieme per Lucio&rdquo; Vivi Arte Viva &ndash; Borgaro Torinese</li><li>Collettiva &ldquo;Confronti&rdquo; - Vivi Arte Viva &ndash; Chiostro dell&#39;Annunziata &ndash; Torino</li><li>Collettiva &ldquo;Inno Alla Natura&rdquo; Museo Civico G.Sciortino &ndash; Monreale</li><li>Collettiva &ldquo;Rosso D&#39;Arte&rdquo; - Sala Gatti &ndash; Viterbo</li><li>Collettiva &ldquo;Libro Opera D&#39;Arte&rdquo; - Vivi Arte Viva &ndash; Centro Polisportivo Robiland &ndash; Torino</li><li>Collettiva &ldquo;Avanguardie Artistiche 2009&rdquo; - Il Tempio &ndash; Palermo</li><li>Collettiva &ldquo;Arte Nuova&rdquo; - Educatorio della Provvidenza &ndash; Torino</li><li>Collettiva &ldquo;Insieme per Lucio&rdquo; Vivi Arte Viva &ndash; Biblioteca Villa Amoretti &ndash; Torino</li><li>Collettiva &ldquo;Premi Ren&egrave; Magritte&rdquo; Gall. Amart Luise &ndash; Bruxelles</li><li>Collettiva dei Finalisti &ldquo; Il Segno&rdquo; Premi d&#39;Arte Contenporanea Gall. Zamenhof &ndash; Milano</li><li>Mostra &ldquo;Agrigento Arte&rdquo;</li><li>Collettiva &ldquo;I Colori dell&#39;Autunno&rdquo; - Gall. Il Tempio &ndash; Palermo</li><li>Prima Mostra Regionale di Pittura Contemporanea - Mazara del Vallo<br /></li></ul><p>&nbsp;</p><p><strong>2010&nbsp;&nbsp; &nbsp;<br /></strong></p><ul><li>Collettiva &ldquo;Autunno Artistico&rdquo; Call- Il Tempio &ndash; Palermo</li><li>Collettiva &ldquo;Trofeo Il Tempio Alla Carriera&rdquo; Gall. Il Tempio Palermo</li><li>Collettiva &ldquo;1&deg; Premio Internazione Citt&agrave; di New York&rdquo; Artisti in Mostra a Palermo Gall. Il Tempio</li><li>Collettiva&quot;Mani delle Donne&quot; Pittura Teatralizzata - FIDAPA Partanna <br /></li><li>Collettiva &ldquo;Riflessioni del Contemporaneo&rdquo; Gall. Centro D&#39;Arte San Vidal &ndash; Venezia</li><li>Collettiva &ldquo;Riflessioni del Contemporaneo&rdquo; Gall. D&#39;Arte Transvisionismo &ndash; Castell&#39;Arquato &ndash; Piacenza</li><li>Collettiva &ldquo;Riflessioni del Contemporaneo&rdquo; Gall. D&#39;Arte Sansoni &ndash; Pavia</li><li>Collettiva &ldquo;Inverno Artistico&rdquo; Gall. Il Tempio &ndash; Palermo</li></ul><br /><strong>2011&nbsp;&nbsp; &nbsp;<br /></strong><ul><li>Collettiva &ldquo;Emozioni nell&#39;Arte&rdquo; Gall. Il Tempio &ndash; Palermo</li><li>Collettiva &ldquo;Racconti di Colori&rdquo; Gall. Vivi Arte Viva &ndash; Torino</li><li>Collettiva &ldquo;Raccolta d&#39;Arte Contemporanea Italiana&rdquo; Museo Civico G.Sciortino &ndash; Monreale</li><li>Collettiva &ldquo;Emozioni nell&#39;Arte&rdquo; Gall. Il Tempio &ndash; Palermo</li><li>Collettiva &ldquo;Premio Guglielmo II&rdquo; Gall. Civica d&#39;Arte Moderna G-Sciortino &ndash; Monreale</li><li>Collettiva Galleria Gi&ograve; Art - Lucca<br /></li><li>Collettiva &ldquo;Dall&#39;Italia alle Fiandre&rdquo; Galleria Transvisionismo &ndash; Aalst &ndash; Belgio</li><li>Collettiva &ldquo;Art Metr&ograve; Gallery&rdquo; - Torre Alberici Casa della Gabella &ndash; Bologna</li><li>Collettiva &quot;Arte in Passerella&quot; Villa Malfitano Whitaker - Palermo</li><li>Personale &quot;Il Giardino dell&#39;Arte&quot; - Selinunte</li><li>Selezionata per &quot;Quadriennale Leonardo Da Vinci&quot;<br /></li><li>Collettiva &quot;The Others&quot; Art Metr&ograve; Gallery - Carceri Nuove - Torino</li><li>Collettiva &quot;Art Metr&ograve; Gallery - Torre Alberici &ndash; Casa della Gabella &ndash; Bologna</li><li>Convegno e Mostra d&#39;Arte &ldquo;La Memoria e il Presagio&rdquo; L&#39;Ecclettismo nelle Arti &ndash; Omaggio Allarchitetto Armando Brasini &ndash; A Cura del Conte Daniele Radini Tedeschi e del Prof. Sergio Rossi &ndash; Complesso Monumentale del Buon Pastore &ndash; Roma</li></ul><strong>2012&nbsp;&nbsp; &nbsp;<br /></strong><ul><li>Collettiva &ldquo;Amici Insieme per l&#39;Arte&rdquo; - Chiesa San Pietro &ndash; Marsala</li><li>Collettiva &ldquo;Sport In Tour&rdquo; Quando lo Sport &egrave; Sociale &ndash; U.S.Acli Siclia &ndash; Circolo Ufficilia &ndash; Palermo</li><li>Exp&ograve; Bari Art Metr&ograve; Gallery<br /></li><li>Triennale di Roma &ldquo;I Big dell&#39;Arte Contemporanea&rdquo; Roma</li><li>Collettiva &ldquo;Le Cravatte ROD&#39;A&#39;&rdquo; Galleria Katane &ndash; Catania</li><li>Personale &quot;Il Giardino dell&#39;Arte&quot; &ndash; Selinunte</li><li>Collettiva &ldquo;Salut&#39;Art&rdquo; ACLI &ndash; Palermo</li><li>Notte Bianca Palermo</li><li>&ldquo;Grande Exp&ograve; alla Sapienza&rdquo; - Museo de&ograve; Rettorato Universit&agrave; degli Studi la Sapienza &ndash; Roma &ndash; Mostra Curata dal Conte Daniele Radini Tedeschi &ndash; Una giornata &egrave; stata dedicata allo studio delle opere in mostra con gli studenti della Sapienza</li></ul><p>2013</p><ul><li>Collettiva VI Edizione - &quot;Premio della Lupa&quot; Galleria &quot;La Pigna&quot; - Palazzo Pontificio Maffei Marescotti - Roma <br /></li><li>Selezionata per bebopart.com portale internet - di Vittorio Sgarbi</li></ul><p><strong>Premi e Riconoscimenti </strong></p><p>2008&nbsp;&nbsp;&nbsp; </p><ul><li>3&deg; Premio Internazionele Bo&egrave; &ndash; Palermo<br /></li></ul><p>2009&nbsp;&nbsp;&nbsp; </p><ul><li>3&deg; Premio Internazionele &ldquo;Inno Alla Natura&rdquo;</li><li>Finalista Premi &ldquo;Il Segno&rdquo; (con menzione particolare) - Milano</li><li>1&deg; Premio &ldquo;Santa Sara&rdquo; - Alessandria</li><li>2&deg; Concorso D&#39;Arte Internazionale &ldquo;Rosso D&#39;Arte&rdquo; - Viterbo</li><li>Premio Iternazionale &ldquo;Ren&egrave; Magritte&rdquo; - Bruxelles<br /></li></ul><p>2010&nbsp;&nbsp;&nbsp; </p><ul><li>1&deg; Premio Internazionale &ldquo;Citt&agrave; di New York&rdquo;</li><li>Premio Alla Carriera &ldquo;Trofeo il Tempio&rdquo; - Palermo</li><li>Premi &ldquo;L&#39;Ercole di Brindisi&rdquo; con Nomina di &ldquo;Ambasciatore dell&#39;Arte del Mediterraneo&rdquo; - Palazzo della Provincia di Brindisi<br /></li></ul><p>2011&nbsp;&nbsp;&nbsp; </p><ul><li>Premio &ldquo;Guglielmo II&rdquo; - Monreale</li><li>Premio Internazionale &ldquo;Tokio&rdquo;</li><li>Arte in Passerella<br /></li></ul><p>2012&nbsp;&nbsp;&nbsp; </p><ul><li>Premio Arte Pentafoglio &ndash; Unasp Acli &ldquo;Sport in Tour&rdquo; 2&deg; Classificato &ndash; Palermo</li><li>Premio Citt&agrave; di Washington </li></ul><p>&nbsp;2013</p><ul><li>Al &quot;Premio della Lupa&quot; Ha ricevuto l&#39;importante premio della critica e la medaglia dell&#39;Accademia dei Santi Lazzaro Ignazio di Loyola, Francesco Borgia <br /></li></ul><p><strong>Pubblicazioni</strong></p><ul><li>Arte - Mondadori</li><li>Bo&eacute; - Centro Diffuzione Arte</li><li>Catalogo &quot;Il Segno&quot; - Premio Arte Contemporanea 2009</li><li>Catalogo Agrigento Arte</li><li>Avanguardie Artistiche 2009 - Centro Diffuzione Arte</li><li>Avanguardie Artistiche 2010 - Centro Diffuzione Arte</li><li>Catalogo &quot;1&deg; Premio Santa Sara&quot;</li><li>Catalogo SarArt 2010</li><li>Catalogo &quot;Riflessioni del Contemporaneo&quot;</li><li>Catalogo &quot;L&#39;Ercole di Brindisi&quot; </li><li>C.A.I. 2010 - Cesimento Artistico Italiano - Centro Diffuzione Arte</li><li>Grandi Maestri 2011 - Centro Diffusione Arte</li><li>Monreale - Una Raccolta d&#39;Arte Contemporanea Italiana - Centro Diffusione Arte</li><li>Red Magazine</li><li>Effetto Arte - EA Editore</li><li>Over Art - EA Editore <br /></li></ul><p>&nbsp;</p>', '', 1, 1, 0, 1, '2013-01-15 22:39:28', 62, '', '2013-06-20 21:44:20', 62, 62, '2013-06-20 21:44:20', '2013-01-15 22:37:39', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 10, 0, 2, '', '', 0, 4463);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_content_frontpage`
--

CREATE TABLE `roda_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_content_frontpage`
--

INSERT INTO `roda_content_frontpage` (`content_id`, `ordering`) VALUES
(3, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_content_rating`
--

CREATE TABLE `roda_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rating_count` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_acl_aro`
--

CREATE TABLE `roda_core_acl_aro` (
  `aro_id` int(11) NOT NULL,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_core_acl_aro`
--

INSERT INTO `roda_core_acl_aro` (`aro_id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_acl_aro_groups`
--

CREATE TABLE `roda_core_acl_aro_groups` (
  `group_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_core_acl_aro_groups`
--

INSERT INTO `roda_core_acl_aro_groups` (`group_id`, `parent_id`, `name`, `lft`, `rgt`) VALUES
(17, 0, 'ROOT', 1, 22),
(28, 17, 'USERS', 2, 21),
(29, 28, 'Public Frontend', 3, 12),
(18, 29, 'Registered', 4, 11),
(19, 18, 'Author', 5, 10),
(20, 19, 'Editor', 6, 9),
(21, 20, 'Publisher', 7, 8),
(30, 28, 'Public Backend', 13, 20),
(23, 30, 'Manager', 14, 19),
(24, 23, 'Administrator', 15, 18),
(25, 24, 'Super Administrator', 16, 17);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_acl_aro_sections`
--

CREATE TABLE `roda_core_acl_aro_sections` (
  `section_id` int(11) NOT NULL,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_core_acl_aro_sections`
--

INSERT INTO `roda_core_acl_aro_sections` (`section_id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_acl_groups_aro_map`
--

CREATE TABLE `roda_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_core_acl_groups_aro_map`
--

INSERT INTO `roda_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(25, '', 10);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_log_items`
--

CREATE TABLE `roda_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_core_log_searches`
--

CREATE TABLE `roda_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_groups`
--

CREATE TABLE `roda_groups` (
  `id` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_groups`
--

INSERT INTO `roda_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_jce_langs`
--

CREATE TABLE `roda_jce_langs` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL DEFAULT '',
  `lang` varchar(100) NOT NULL DEFAULT '',
  `published` tinyint(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_jce_langs`
--

INSERT INTO `roda_jce_langs` (`id`, `Name`, `lang`, `published`) VALUES
(1, 'English', 'en', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_jce_plugins`
--

CREATE TABLE `roda_jce_plugins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `plugin` varchar(100) NOT NULL DEFAULT '',
  `type` varchar(100) NOT NULL DEFAULT 'plugin',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `layout_icon` varchar(255) NOT NULL DEFAULT '',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '18',
  `row` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `editable` tinyint(3) NOT NULL DEFAULT '0',
  `elements` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_jce_plugins`
--

INSERT INTO `roda_jce_plugins` (`id`, `name`, `plugin`, `type`, `icon`, `layout_icon`, `access`, `row`, `ordering`, `published`, `editable`, `elements`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Context Menu', 'contextmenu', 'plugin', '', '', 18, 0, 0, 0, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Directionality', 'directionality', 'plugin', 'ltr,rtl', 'directionality', 18, 3, 8, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(3, 'Emotions', 'emotions', 'plugin', 'emotions', 'emotions', 18, 4, 12, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Fullscreen', 'fullscreen', 'plugin', 'fullscreen', 'fullscreen', 18, 4, 6, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'Paste', 'paste', 'plugin', 'pasteword,pastetext', 'paste', 18, 1, 16, 1, 1, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(6, 'Preview', 'preview', 'plugin', 'preview', 'preview', 18, 4, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(7, 'Tables', 'table', 'plugin', 'tablecontrols', 'buttons', 18, 2, 8, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(8, 'Print', 'print', 'plugin', 'print', 'print', 18, 4, 3, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(9, 'Search Replace', 'searchreplace', 'plugin', 'search,replace', 'searchreplace', 18, 1, 17, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(10, 'Styles', 'style', 'plugin', 'styleprops', 'styleprops', 18, 4, 7, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(11, 'Non-Breaking', 'nonbreaking', 'plugin', 'nonbreaking', 'nonbreaking', 18, 4, 8, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(12, 'Visual Characters', 'visualchars', 'plugin', 'visualchars', 'visualchars', 18, 4, 9, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(13, 'XHTML Xtras', 'xhtmlxtras', 'plugin', 'cite,abbr,acronym,del,ins,attribs', 'xhtmlxtras', 18, 4, 10, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Image Manager', 'imgmanager', 'plugin', '', 'imgmanager', 18, 4, 13, 1, 1, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(15, 'Advanced Link', 'advlink', 'plugin', '', 'advlink', 18, 4, 14, 1, 1, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Spell Checker', 'spellchecker', 'plugin', 'spellchecker', 'spellchecker', 18, 4, 15, 1, 1, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(17, 'Layers', 'layer', 'plugin', 'insertlayer,moveforward,movebackward,absolute', 'layer', 18, 4, 11, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(18, 'Font ForeColour', 'forecolor', 'command', 'forecolor', 'forecolor', 18, 3, 4, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Bold', 'bold', 'command', 'bold', 'bold', 18, 1, 5, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(20, 'Italic', 'italic', 'command', 'italic', 'italic', 18, 1, 6, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Underline', 'underline', 'command', 'underline', 'underline', 18, 1, 7, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Font BackColour', 'backcolor', 'command', 'backcolor', 'backcolor', 18, 3, 5, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Unlink', 'unlink', 'command', 'unlink', 'unlink', 18, 2, 11, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'Font Select', 'fontselect', 'command', 'fontselect', 'fontselect', 18, 3, 2, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'Font Size Select', 'fontsizeselect', 'command', 'fontsizeselect', 'fontsizeselect', 18, 3, 3, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(26, 'Style Select', 'styleselect', 'command', 'styleselect', 'styleselect', 18, 3, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(27, 'New Document', 'newdocument', 'command', 'newdocument', 'newdocument', 18, 1, 4, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'Help', 'help', 'command', 'help', 'help', 18, 1, 3, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(29, 'StrikeThrough', 'strikethrough', 'command', 'strikethrough', 'strikethrough', 18, 1, 12, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(30, 'Indent', 'indent', 'command', 'indent', 'indent', 18, 1, 11, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(31, 'Outdent', 'outdent', 'command', 'outdent', 'outdent', 18, 1, 10, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'Undo', 'undo', 'command', 'undo', 'undo', 18, 1, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'Redo', 'redo', 'command', 'redo', 'redo', 18, 1, 2, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'Horizontal Rule', 'hr', 'command', 'hr', 'hr', 18, 2, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(35, 'HTML', 'html', 'command', 'code', 'code', 18, 1, 13, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(36, 'Numbered List', 'numlist', 'command', 'numlist', 'numlist', 18, 1, 9, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(37, 'Bullet List', 'bullist', 'command', 'bullist', 'bullist', 18, 1, 8, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(38, 'Clipboard Actions', 'clipboard', 'command', 'cut,copy,paste', 'clipboard', 18, 1, 16, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(39, 'Subscript', 'sub', 'command', 'sub', 'sub', 18, 2, 2, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(40, 'Superscript', 'sup', 'command', 'sup', 'sup', 18, 2, 3, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(41, 'Visual Aid', 'visualaid', 'command', 'visualaid', 'visualaid', 18, 3, 7, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(42, 'Character Map', 'charmap', 'command', 'charmap', 'charmap', 18, 3, 6, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(43, 'Justify Full', 'full', 'command', 'justifyfull', 'justifyfull', 18, 2, 7, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(44, 'Justify Center', 'center', 'command', 'justifycenter', 'justifycenter', 18, 2, 5, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(45, 'Justify Left', 'left', 'command', 'justifyleft', 'justifyleft', 18, 2, 6, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(46, 'Justify Right', 'right', 'command', 'justifyright', 'justifyright', 18, 2, 4, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(47, 'Remove Format', 'removeformat', 'command', 'removeformat', 'removeformat', 18, 1, 15, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(48, 'Anchor', 'anchor', 'command', 'anchor', 'anchor', 18, 2, 9, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(49, 'Format Select', 'formatselect', 'command', 'formatselect', 'formatselect', 18, 3, 9, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(50, 'Image', 'image', 'command', 'image', 'image', 18, 4, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', ''),
(51, 'Link', 'link', 'command', 'link', 'link', 18, 4, 1, 1, 0, '', 1, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_mambots`
--

CREATE TABLE `roda_mambots` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_mambots`
--

INSERT INTO `roda_mambots` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'MOS Image', 'mosimage', 'content', 0, -10000, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'MOS Pagination', 'mospaging', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(3, 'Legacy Mambot Includer', 'legacybots', 'content', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'SEF', 'mossef', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'MOS Rating', 'mosvote', 'content', 0, 7, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(6, 'Ricerca nei contenuti', 'content.searchbot', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(7, 'Ricerca nei collegamenti web', 'weblinks.searchbot', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(8, 'Supporto codice', 'moscode', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(9, 'Nessun editor WYSIWYG', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(10, 'Editor TinyMCE WYSIWYG', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'theme=advanced'),
(11, 'Bottone editor MOS Image', 'mosimage.btn', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(12, 'Bottone editor MOS Pagebreak', 'mospage.btn', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(13, 'Ricerca nei contati', 'contacts.searchbot', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Ricerca nelle categorie', 'categories.searchbot', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(15, 'Ricerca nelle sezioni', 'sections.searchbot', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Email Cloaking', 'mosemailcloak', 'content', 0, 8, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(17, 'GeSHi', 'geshi', 'content', 0, 9, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(18, 'Ricerca nei newsfeeds', 'newsfeeds.searchbot', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Carica posizione moduli', 'mosloadposition', 'content', 0, 10, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(20, 'Simple Image Gallery Plugin', 'plugin_jw_sig', 'content', 0, 3, 1, 0, 0, 0, '0000-00-00 00:00:00', 'th_width=110\nth_height=110\nth_quality=50\ndisplaynavtip=1\nnavtip=Navigation tip: Hover mouse on top of the right or left side of the image to see the next or previous image respectively.\ndisplaymessage=0\nmessage=You are browsing images from the article:'),
(21, 'RD Add PHP', 'rd_addphp', 'content', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'JCK', 'jck', 'editors', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'XStandard Editor', 'xstandard', 'editors', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'RokTextile', 'roktextile', 'content', 0, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'ARTIO JoomSEF MetaBot', 'joomsef_metabot', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'rewrite_keywords=1\nrewrite_description=1\nprefer_joomsef_title=1\nuse_sitename=2\nsitename_sep=&nbsp;-&nbsp;');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_menu`
--

CREATE TABLE `roda_menu` (
  `id` int(11) NOT NULL,
  `menutype` varchar(25) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `componentid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_menu`
--

INSERT INTO `roda_menu` (`id`, `menutype`, `name`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`) VALUES
(1, 'mainmenu', 'Home', 'index.php?option=com_frontpage', 'components', 1, 0, 10, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'leading=1\r\nintro=2\r\ncolumns=1\r\nlink=1\r\nimage=1\r\npage_title=0\r\nheader=Benvenuto in prima pagina\r\norderby_sec=front\r\nprint=0\r\npdf=0\r\nemail=0\r\nback_button=0'),
(2, 'homemenu', 'Biografia', 'index.php?option=com_content&task=view&id=1', 'content_item_link', 1, 0, 1, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0'),
(3, 'homemenu', 'Galleria', 'index.php?option=com_content&task=view&id=4', 'content_item_link', 1, 0, 4, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0'),
(4, 'homemenu', 'Recensioni', 'index.php?option=com_content&task=view&id=5', 'content_item_link', 1, 0, 5, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0'),
(5, 'homemenu', 'Contatti', 'index.php?option=com_contact&task=view&contact_id=1', 'contact_item_link', 1, 0, 1, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\npageclass_sfx=\npage_title=1\nheader=\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=0'),
(6, 'homemenu', 'quadri', 'index.php?option=com_content&task=category&sectionid=2&id=3', 'content_category', -2, 0, 3, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\npage_title=0\npageclass_sfx=\nback_button=\ndescription_cat=1\ndescription_cat_image=1\norderby=\ndate_format=\ndate=\nauthor=\nhits=\nheadings=1\nnavigation=1\norder_select=1\ndisplay=1\ndisplay_num=50\nfilter=1\nfilter_type=title\nother_cat=1\nempty_cat=0\ncat_items=1\ncat_description=1\nunpublished=0'),
(7, 'homemenu', 'Curriculum', 'index.php?option=com_content&task=view&id=30', 'content_item_link', 1, 0, 30, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0'),
(8, 'homemenu', 'Dicono di me', 'index.php?option=com_content&task=view&id=34', 'content_item_link', 1, 0, 34, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_messages`
--

CREATE TABLE `roda_messages` (
  `message_id` int(10) UNSIGNED NOT NULL,
  `user_id_from` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_id_to` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `folder_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) UNSIGNED NOT NULL DEFAULT '0',
  `subject` varchar(230) NOT NULL DEFAULT '',
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_messages_cfg`
--

CREATE TABLE `roda_messages_cfg` (
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_modules`
--

CREATE TABLE `roda_modules` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(10) DEFAULT NULL,
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_modules`
--

INSERT INTO `roda_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`) VALUES
(1, 'Sondaggi', '', 1, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_poll', 0, 0, 1, '', 0, 0),
(2, 'Menu utente', '', 3, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 1, 1, 'menutype=usermenu', 1, 0),
(3, 'Menu principale', '', 1, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu', 1, 0),
(4, 'Login Form', '', 4, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 0),
(5, 'Syndication', '', 6, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_rssfeed', 0, 0, 1, '', 1, 0),
(6, 'Ultime notizie', '', 4, 'user1', 0, '0000-00-00 00:00:00', 1, 'mod_latestnews', 0, 0, 1, '', 1, 0),
(7, 'Statistiche', '', 5, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_stats', 0, 0, 1, 'serverinfo=1\nsiteinfo=1\ncounter=1\nincrease=0\nmoduleclass_sfx=', 0, 0),
(8, 'Chi e\' online', '', 1, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_whosonline', 0, 0, 1, 'online=1\nusers=1\nmoduleclass_sfx=', 0, 0),
(9, 'I piu\' letti', '', 6, 'user2', 0, '0000-00-00 00:00:00', 1, 'mod_mostread', 0, 0, 1, '', 0, 0),
(10, 'Scelta template', '', 7, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_templatechooser', 0, 0, 1, 'show_preview=1', 0, 0),
(11, 'Archivio', '', 8, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_archive', 0, 0, 1, '', 1, 0),
(12, 'Sezioni', '', 9, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_sections', 0, 0, 1, '', 1, 0),
(13, 'Annunci', '', 1, 'top', 0, '0000-00-00 00:00:00', 1, 'mod_newsflash', 0, 0, 1, 'catid=3\r\nstyle=random\r\nitems=\r\nmoduleclass_sfx=', 0, 0),
(14, 'Articoli correlati', '', 10, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_related_items', 0, 0, 1, '', 0, 0),
(15, 'Cerca', '', 1, 'user4', 0, '0000-00-00 00:00:00', 1, 'mod_search', 0, 0, 0, '', 0, 0),
(16, 'Immagine casuale', '', 9, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_random_image', 0, 0, 1, '', 0, 0),
(17, 'Top Menu', '', 1, 'user3', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'menutype=topmenu\nmenu_style=list_flat\nmenu_images=n\nmenu_images_align=left\nexpand_menu=n\nclass_sfx=-nav\nmoduleclass_sfx=\nindent_image1=0\nindent_image2=0\nindent_image3=0\nindent_image4=0\nindent_image5=0\nindent_image6=0', 1, 0),
(18, 'Banner', '', 1, 'banner', 0, '0000-00-00 00:00:00', 1, 'mod_banners', 0, 0, 0, 'banner_cids=\nmoduleclass_sfx=\n', 1, 0),
(19, 'Componenti', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_components', 0, 99, 1, '', 1, 1),
(20, 'I piu\' letti', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 99, 1, '', 0, 1),
(21, 'Articoli recenti', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 99, 1, '', 0, 1),
(22, 'Stato menu', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 99, 1, '', 0, 1),
(23, 'Messaggi non letti', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 99, 1, '', 1, 1),
(24, 'Utenti connessi', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 99, 1, '', 1, 1),
(25, 'Full Menu', '', 1, 'top', 0, '0000-00-00 00:00:00', 1, 'mod_fullmenu', 0, 99, 1, '', 1, 1),
(26, 'Pathway', '', 1, 'pathway', 0, '0000-00-00 00:00:00', 1, 'mod_pathway', 0, 99, 1, '', 1, 1),
(27, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 99, 1, '', 1, 1),
(28, 'Messaggi di sistema', '', 1, 'inset', 0, '0000-00-00 00:00:00', 1, 'mod_mosmsg', 0, 99, 1, '', 1, 1),
(29, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 99, 1, '', 1, 1),
(30, 'Other Menu', '', 2, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'menutype=othermenu\nmenu_style=vert_indent\ncache=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nclass_sfx=\nmoduleclass_sfx=\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=', 0, 0),
(31, 'Wrapper', '', 11, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_wrapper', 0, 0, 1, '', 0, 0),
(32, 'Connessi', '', 0, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 99, 1, '', 0, 1),
(33, 'homemenu', '', 1, 'menuhome', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'class_sfx=-mh\nmoduleclass_sfx=-mh\nmenutype=homemenu\nmenu_style=list_flat\nfull_active_id=0\ncache=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=|\nend_spacer=|', 0, 0),
(34, 'Notizie', '', 2, 'menuhome', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 1, 'moduleclass_sfx=_newshome\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=5\ncount=3\norderby=4\noutputorder=6\ncustomorder=\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=1\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=20\nreadmore=1\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(35, 'Pensieri nel footer', '', 1, 'foopens', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 0, 'moduleclass_sfx=_random\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=2\ncount=1\norderby=8\noutputorder=-1\ncustomorder=text\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=0\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=\nreadmore=0\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(36, 'Recenzioni', '', 1, 'reces', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 0, 'moduleclass_sfx=_reces\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=4\ncount=30\norderby=7\noutputorder=1\ncustomorder=\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=1\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=22\nreadmore=1\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(37, 'Link', '', 3, 'menuhome', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 1, 'moduleclass_sfx=_link\nitemid=\nwhere=content\nwhere_id=13\nsection_id=0\ncategory_id=0\ncount=1\norderby=4\noutputorder=-1\ncustomorder=text\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=1\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=\nreadmore=0\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(38, 'Notizie messe a sinistra', '', 1, 'leftx', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 0, 'moduleclass_sfx=_leftx\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=5\ncount=1\norderby=4\noutputorder=6\ncustomorder=\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=1\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=20\nreadmore=1\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(39, 'Archivio Notizie', '', 1, 'archno', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 0, 'moduleclass_sfx=_reces\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=5\ncount=30\norderby=1\noutputorder=1\ncustomorder=\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=0\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=40\nreadmore=1\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0),
(40, 'Dicono di me', '', 1, 'dicon', 0, '0000-00-00 00:00:00', 1, 'mod_flexcontent', 0, 0, 0, 'moduleclass_sfx=_reces\nitemid=\nwhere=category\nwhere_id=\nsection_id=1\ncategory_id=9\ncount=30\norderby=7\noutputorder=1\ncustomorder=\nprocessmambots=0\ntimeperiod=0\nskipstories=\nlastimage=1\nlinkedtitle=1\nlinkedimg=0\nlinkedtxt=0\nlinkeddate=0\nlinkedauthor=0\nlinkedcat=0\nlinkedsection=0\ncatlink=0\ncatlinktext=\nseclink=0\nseclinktext=\nchars=\nwords=22\nreadmore=1\ncycle=\nbonusdiv=0\nshowcatname=0\nlinkcatname=0\ncatitemid=\ncatnameprefix=\ncatnamesuffix=\nrssurl=\nrsstitle=0\nrsslink=0\nrssdesc=0', 0, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_modules_menu`
--

CREATE TABLE `roda_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_modules_menu`
--

INSERT INTO `roda_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 1),
(2, 0),
(3, 0),
(4, 1),
(5, 1),
(6, 1),
(6, 2),
(6, 4),
(6, 27),
(6, 36),
(8, 1),
(9, 1),
(9, 2),
(9, 4),
(9, 27),
(9, 36),
(10, 1),
(13, 0),
(15, 0),
(17, 0),
(18, 0),
(30, 0),
(33, 0),
(34, 1),
(35, 0),
(36, 0),
(37, 1),
(38, 0),
(39, 0),
(40, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_newsfeeds`
--

CREATE TABLE `roda_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `cache_time` int(11) UNSIGNED NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_polls`
--

CREATE TABLE `roda_polls` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_poll_data`
--

CREATE TABLE `roda_poll_data` (
  `id` int(11) NOT NULL,
  `pollid` int(4) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_poll_date`
--

CREATE TABLE `roda_poll_date` (
  `id` bigint(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_poll_menu`
--

CREATE TABLE `roda_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_redirection`
--

CREATE TABLE `roda_redirection` (
  `id` int(11) NOT NULL,
  `cpt` int(11) NOT NULL DEFAULT '0',
  `oldurl` varchar(255) NOT NULL,
  `newurl` varchar(255) NOT NULL,
  `Itemid` varchar(20) DEFAULT NULL,
  `metadesc` varchar(255) DEFAULT '',
  `metakey` varchar(255) DEFAULT '',
  `metatitle` varchar(255) DEFAULT '',
  `metalang` varchar(30) DEFAULT '',
  `metarobots` varchar(30) DEFAULT '',
  `metagoogle` varchar(30) DEFAULT '',
  `dateadd` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_redirection`
--

INSERT INTO `roda_redirection` (`id`, `cpt`, `oldurl`, `newurl`, `Itemid`, `metadesc`, `metakey`, `metatitle`, `metalang`, `metarobots`, `metagoogle`, `dateadd`) VALUES
(33, 7, 'recensioni/', 'index.php?option=com_content&id=4&task=blogcategory', '0', '', '', '', '', '', '', '0000-00-00'),
(32, 4577, 'news/hanno-scritto-di-rod.html', 'index.php?option=com_content&id=20&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(16, 20159, 'contatti/rod-a/rosalba-darienzo.html', 'index.php?option=com_contact&contact_id=1&task=view', '5', 'contatti,telefono,email rod\'à', '', 'Contatti', '', '', '', '2010-04-03'),
(31, 1087, 'pagine-catalogo/vetri.html', 'index.php?option=com_content&id=15&task=view', NULL, '', '', '', '', '', '', '0000-00-00'),
(14, 6510, 'recensioni.html', 'index.php?option=com_content&id=5&task=view', '4', '', '', '', '', '', '', '2010-04-03'),
(15, 6781, 'galleria.html', 'index.php?option=com_content&id=4&task=view', '3', '', '', '', '', '', '', '2010-04-03'),
(13, 6712, 'biografia.html', 'index.php?option=com_content&id=1&task=view', '2', '', '', '', '', '', '', '2010-04-03'),
(21, 9045, 'contatti.html', 'index.php?option=com_contact', '5', 'contatti,telefono,email rod\'à', '', 'Contatti', '', '', '', '2010-04-03'),
(12, 0, 'home page.html', 'index.php?option=com_content&id=3&task=view', '1', '', '', 'ROD\'A\' presentazione', '', '', '', '2010-04-03'),
(22, 1059, 'pagine/archivio-notizie.html', 'index.php?option=com_content&id=14&task=view', '4', '', '', 'Notizie', '', '', '', '2010-04-03'),
(30, 925, 'pagine/link.html', 'index.php?option=com_content&id=13&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(29, 0, 'pagine/', 'index.php?option=com_content&id=1&task=blogcategory', '0', '', '', '', '', '', '', '0000-00-00'),
(28, 6, 'news/', 'index.php?option=com_content&id=5&task=blogcategory', '0', '', '', '', '', '', '', '0000-00-00'),
(27, 0, 'vita/', 'index.php?option=com_content&id=1&task=blogsection', '0', '', '', '', '', '', '', '0000-00-00'),
(34, 2314, 'recensioni/vittoria-colpi.html', 'index.php?option=com_content&id=26&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(35, 2361, 'recensioni/paolo-levi.html', 'index.php?option=com_content&id=27&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(36, 2267, 'recensioni/nadine-giove.html', 'index.php?option=com_content&id=28&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(37, 3247, 'recensioni/flavio-de-gregorio.html', 'index.php?option=com_content&id=23&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(38, 2430, 'recensioni/elena-cicchetti.html', 'index.php?option=com_content&id=25&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(39, 2539, 'recensioni/dino-maras.html', 'index.php?option=com_content&id=22&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(40, 2309, 'recensioni/daniele-radini-tedeschi.html', 'index.php?option=com_content&id=29&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(41, 2398, 'recensioni/anna-francesca-biondolillo.html', 'index.php?option=com_content&id=24&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(42, 4464, 'pagine/curriculum.html', 'index.php?option=com_content&id=30&task=view', '7', '', '', '', '', '', '', '0000-00-00'),
(43, 0, 'pensieri/', 'index.php?option=com_content&id=2&task=blogcategory', '0', '', '', '', '', '', '', '0000-00-00'),
(44, 2350, 'pensieri/il-rosso-e-il-nero-roda.html', 'index.php?option=com_content&id=32&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(45, 2424, 'pensieri/nota-critica-a-rosalba-darienzo-roda.html', 'index.php?option=com_content&id=33&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(46, 2244, 'pensieri/oltre-il-tempo-oltre-il-colore-oltre.html', 'index.php?option=com_content&id=31&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(47, 3763, 'pagine/dicono-di-me.html', 'index.php?option=com_content&id=34&task=view', '8', '', '', '', '', '', '', '0000-00-00'),
(48, 0, 'dicono-di-me/', 'index.php?option=com_content&id=9&task=blogcategory', '0', '', '', '', '', '', '', '0000-00-00'),
(49, 2233, 'recensioni/sandro-serradifalco.html', 'index.php?option=com_content&id=35&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(50, 2110, 'recensioni/giancarlo-al.html', 'index.php?option=com_content&id=36&task=view', '0', '', '', '', '', '', '', '0000-00-00'),
(51, 50, 'password-dimenticata.html', 'index.php?option=com_registration&task=lostPassword', NULL, '', '', '', '', '', '', '0000-00-00'),
(52, 53, 'registrazione.html', 'index.php?option=com_registration&task=register', NULL, '', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_sections`
--

CREATE TABLE `roda_sections` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(100) NOT NULL DEFAULT '',
  `scope` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(10) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_sections`
--

INSERT INTO `roda_sections` (`id`, `title`, `name`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'Vita', 'Vita', '', 'content', 'left', '', 1, 62, '2011-10-08 09:59:59', 2, 0, 7, 'imagefolders=*1*'),
(2, 'Opere', 'Opere', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 1, 0, 9, 'imagefolders=*1*');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_sefexts`
--

CREATE TABLE `roda_sefexts` (
  `id` int(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `params` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_sefexts`
--

INSERT INTO `roda_sefexts` (`id`, `file`, `title`, `params`) VALUES
(1, 'com_alphacontent.xml', NULL, NULL),
(2, 'com_banners.xml', NULL, NULL),
(3, 'com_contact.xml', NULL, NULL),
(4, 'com_content.xml', NULL, NULL),
(5, 'com_docman.xml', NULL, NULL),
(6, 'com_forum.xml', NULL, NULL),
(7, 'com_frontpage.xml', NULL, NULL),
(8, 'com_glossary.xml', NULL, NULL),
(9, 'com_joomlaboard.xml', NULL, NULL),
(10, 'com_mtree.xml', NULL, NULL),
(11, 'com_newsfeeds.xml', NULL, NULL),
(12, 'com_registration.xml', NULL, NULL),
(13, 'com_remository.xml', NULL, NULL),
(14, 'com_search.xml', NULL, NULL),
(15, 'com_weblinks.xml', NULL, NULL),
(16, 'com_wrapper.xml', NULL, 'ignoreSource=0\nitemid=1\noverrideId='),
(17, 'com_jce.xml', '', NULL),
(18, 'com_poll.xml', '', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_sefexttexts`
--

CREATE TABLE `roda_sefexttexts` (
  `id` int(11) NOT NULL,
  `extension` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_sefexttexts`
--

INSERT INTO `roda_sefexttexts` (`id`, `extension`, `name`, `value`) VALUES
(1, 'com_mtree', '_MT_SEF_MYPAGE', 'mypage'),
(2, 'com_mtree', '_MT_SEF_FEATUREDLISTING', 'Featured Listing'),
(3, 'com_mtree', '_MT_SEF_NEWLISTING', 'New Listing'),
(4, 'com_mtree', '_MT_SEF_RECENTLYUPDATED', 'Recently Updated'),
(5, 'com_mtree', '_MT_SEF_MOSTFAVOURED', 'Most Favoured'),
(6, 'com_mtree', '_MT_SEF_POPULARLISTING', 'Popular listing'),
(7, 'com_mtree', '_MT_SEF_MOSTRATEDLISTING', 'Most Rated'),
(8, 'com_mtree', '_MT_SEF_TOPRATEDLISTING', 'Top Rated'),
(9, 'com_mtree', '_MT_SEF_MOSTREVIEWEDLISTING', 'Most Reviewed'),
(10, 'com_mtree', '_MT_SEF_OWNER', 'Owner'),
(11, 'com_mtree', '_MT_SEF_FAVOURITES', 'Favourites'),
(12, 'com_mtree', '_MT_SEF_REVIEWS', 'Reviews'),
(13, 'com_mtree', '_MT_SEF_SEARCH', 'Search'),
(14, 'com_mtree', '_MT_SEF_ADVSEARCH', 'AdvSearch'),
(15, 'com_mtree', '_MT_SEF_ADVSEARCH2', 'AdvSearchR'),
(16, 'com_mtree', '_MT_SEF_IMAGE', 'image'),
(17, 'com_mtree', '_MT_SEF_GALLERY', 'gallery'),
(18, 'com_mtree', '_MT_SEF_REVIEW', 'review'),
(19, 'com_mtree', '_MT_SEF_REPLYREVIEW', 'replyreview'),
(20, 'com_mtree', '_MT_SEF_REPORTREVIEW', 'reportreview'),
(21, 'com_mtree', '_MT_SEF_RATE', 'rate'),
(22, 'com_mtree', '_MT_SEF_RECOMMEND', 'recommend'),
(23, 'com_mtree', '_MT_SEF_CONTACT', 'contact'),
(24, 'com_mtree', '_MT_SEF_REPORT', 'report'),
(25, 'com_mtree', '_MT_SEF_CLAIM', 'claim'),
(26, 'com_mtree', '_MT_SEF_VISIT', 'visit'),
(27, 'com_mtree', '_MT_SEF_DELETE', 'delete'),
(28, 'com_mtree', '_MT_SEF_ADDLISTING', 'Add_Listing'),
(29, 'com_mtree', '_MT_SEF_ADDCATEGORY', 'Add_Category');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_sefmoved`
--

CREATE TABLE `roda_sefmoved` (
  `id` int(11) NOT NULL,
  `old` varchar(255) NOT NULL,
  `new` varchar(255) NOT NULL,
  `lastHit` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_sefmoved`
--

INSERT INTO `roda_sefmoved` (`id`, `old`, `new`, `lastHit`) VALUES
(1, 'pagine/presentazione.html', 'home page/presentazione.html', '2011-11-10 23:29:27'),
(2, 'le-opere/galleria.html', 'galleria.html', '2018-05-10 06:50:01'),
(3, 'home page/presentazione.html', 'home page.html', '0000-00-00 00:00:00'),
(4, 'contatti/rod\\\'à rosalba darienzo.html', 'contatti/rosalba darienzo.html', '0000-00-00 00:00:00'),
(5, 'contatti/rosalba darienzo.html', 'contatti/rod-a/rosalba-darienzo.html', '0000-00-00 00:00:00'),
(6, 'pagine/recensioni.html', 'recensioni.html', '2018-04-27 14:35:10'),
(7, 'pagine/biografia.html', 'biografia.html', '2020-08-06 14:20:43');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_session`
--

CREATE TABLE `roda_session` (
  `username` varchar(50) DEFAULT '',
  `time` varchar(14) DEFAULT '',
  `session_id` varchar(200) NOT NULL DEFAULT '0',
  `guest` tinyint(4) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(50) DEFAULT '',
  `gid` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_session`
--

INSERT INTO `roda_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`) VALUES
('admin', '1462970355', '014ffbb2cf79a38d11c8de9a84c0a742', 1, 62, 'Super Administrator', 0),
('', '1637527730', '71a0b4aecf1be36f678e643fa5088df5', 1, 0, '', 0),
('', '1637527195', '842244085f492613c6499b1964369bdf', 1, 0, '', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_stats_agents`
--

CREATE TABLE `roda_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_templates_menu`
--

CREATE TABLE `roda_templates_menu` (
  `template` varchar(50) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_templates_menu`
--

INSERT INTO `roda_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('roda', 0, 0),
('joomla_admin', 0, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_template_positions`
--

CREATE TABLE `roda_template_positions` (
  `id` int(11) NOT NULL,
  `position` varchar(10) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_template_positions`
--

INSERT INTO `roda_template_positions` (`id`, `position`, `description`) VALUES
(1, 'left', ''),
(2, 'right', ''),
(3, 'top', ''),
(4, 'bottom', ''),
(5, 'inset', ''),
(6, 'banner', ''),
(7, 'header', ''),
(8, 'footer', ''),
(9, 'newsflash', ''),
(10, 'legals', ''),
(11, 'pathway', ''),
(12, 'toolbar', ''),
(13, 'cpanel', ''),
(14, 'user1', ''),
(15, 'user2', ''),
(16, 'user3', ''),
(17, 'user4', ''),
(18, 'user5', ''),
(19, 'user6', ''),
(20, 'user7', ''),
(21, 'user8', ''),
(22, 'user9', ''),
(23, 'advert1', ''),
(24, 'advert2', ''),
(25, 'advert3', ''),
(26, 'icon', ''),
(27, 'debug', ''),
(28, 'menuhome', ''),
(29, 'foopens', ''),
(30, 'reces', ''),
(31, 'leftx', ''),
(32, 'archno', ''),
(33, 'dicon', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_users`
--

CREATE TABLE `roda_users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(25) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_users`
--

INSERT INTO `roda_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'rod_a@libero.it', 'bc7d5fb5df18cf7611f2bc6e93a8782c:35yHemh9v9azfinD', 'Super Administrator', 0, 1, 25, '2009-01-27 02:52:04', '2011-11-08 02:38:29', '', 'editor=tinymce\nexpired=\nexpired_time=');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_usertypes`
--

CREATE TABLE `roda_usertypes` (
  `id` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `mask` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `roda_usertypes`
--

INSERT INTO `roda_usertypes` (`id`, `name`, `mask`) VALUES
(0, 'superadministrator', ''),
(1, 'administrator', ''),
(2, 'editor', ''),
(3, 'user', ''),
(4, 'author', ''),
(5, 'publisher', ''),
(6, 'manager', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `roda_weblinks`
--

CREATE TABLE `roda_weblinks` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` varchar(250) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `roda_banner`
--
ALTER TABLE `roda_banner`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `viewbanner` (`showBanner`);

--
-- Indici per le tabelle `roda_bannerclient`
--
ALTER TABLE `roda_bannerclient`
  ADD PRIMARY KEY (`cid`);

--
-- Indici per le tabelle `roda_bannerfinish`
--
ALTER TABLE `roda_bannerfinish`
  ADD PRIMARY KEY (`bid`);

--
-- Indici per le tabelle `roda_categories`
--
ALTER TABLE `roda_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_idx` (`section`,`published`,`access`),
  ADD KEY `idx_section` (`section`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`);

--
-- Indici per le tabelle `roda_components`
--
ALTER TABLE `roda_components`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_contact_details`
--
ALTER TABLE `roda_contact_details`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_content`
--
ALTER TABLE `roda_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_section` (`sectionid`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_catid` (`catid`),
  ADD KEY `idx_mask` (`mask`);

--
-- Indici per le tabelle `roda_content_frontpage`
--
ALTER TABLE `roda_content_frontpage`
  ADD PRIMARY KEY (`content_id`);

--
-- Indici per le tabelle `roda_content_rating`
--
ALTER TABLE `roda_content_rating`
  ADD PRIMARY KEY (`content_id`);

--
-- Indici per le tabelle `roda_core_acl_aro`
--
ALTER TABLE `roda_core_acl_aro`
  ADD PRIMARY KEY (`aro_id`),
  ADD UNIQUE KEY `roda_gacl_section_value_value_aro` (`section_value`(100),`value`(100)),
  ADD KEY `roda_gacl_hidden_aro` (`hidden`);

--
-- Indici per le tabelle `roda_core_acl_aro_groups`
--
ALTER TABLE `roda_core_acl_aro_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `parent_id_aro_groups` (`parent_id`),
  ADD KEY `roda_gacl_parent_id_aro_groups` (`parent_id`),
  ADD KEY `roda_gacl_lft_rgt_aro_groups` (`lft`,`rgt`);

--
-- Indici per le tabelle `roda_core_acl_aro_sections`
--
ALTER TABLE `roda_core_acl_aro_sections`
  ADD PRIMARY KEY (`section_id`),
  ADD UNIQUE KEY `value_aro_sections` (`value`),
  ADD UNIQUE KEY `roda_gacl_value_aro_sections` (`value`),
  ADD KEY `hidden_aro_sections` (`hidden`),
  ADD KEY `roda_gacl_hidden_aro_sections` (`hidden`);

--
-- Indici per le tabelle `roda_core_acl_groups_aro_map`
--
ALTER TABLE `roda_core_acl_groups_aro_map`
  ADD UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`);

--
-- Indici per le tabelle `roda_groups`
--
ALTER TABLE `roda_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_jce_langs`
--
ALTER TABLE `roda_jce_langs`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_jce_plugins`
--
ALTER TABLE `roda_jce_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plugin` (`plugin`);

--
-- Indici per le tabelle `roda_mambots`
--
ALTER TABLE `roda_mambots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_folder` (`published`,`client_id`,`access`,`folder`);

--
-- Indici per le tabelle `roda_menu`
--
ALTER TABLE `roda_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  ADD KEY `menutype` (`menutype`);

--
-- Indici per le tabelle `roda_messages`
--
ALTER TABLE `roda_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indici per le tabelle `roda_messages_cfg`
--
ALTER TABLE `roda_messages_cfg`
  ADD UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`);

--
-- Indici per le tabelle `roda_modules`
--
ALTER TABLE `roda_modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `published` (`published`,`access`),
  ADD KEY `newsfeeds` (`module`,`published`);

--
-- Indici per le tabelle `roda_modules_menu`
--
ALTER TABLE `roda_modules_menu`
  ADD PRIMARY KEY (`moduleid`,`menuid`);

--
-- Indici per le tabelle `roda_newsfeeds`
--
ALTER TABLE `roda_newsfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `published` (`published`);

--
-- Indici per le tabelle `roda_polls`
--
ALTER TABLE `roda_polls`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_poll_data`
--
ALTER TABLE `roda_poll_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pollid` (`pollid`,`text`(1));

--
-- Indici per le tabelle `roda_poll_date`
--
ALTER TABLE `roda_poll_date`
  ADD PRIMARY KEY (`id`),
  ADD KEY `poll_id` (`poll_id`);

--
-- Indici per le tabelle `roda_poll_menu`
--
ALTER TABLE `roda_poll_menu`
  ADD PRIMARY KEY (`pollid`,`menuid`);

--
-- Indici per le tabelle `roda_redirection`
--
ALTER TABLE `roda_redirection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oldurl` (`oldurl`),
  ADD KEY `odkaz` (`newurl`,`Itemid`);

--
-- Indici per le tabelle `roda_sections`
--
ALTER TABLE `roda_sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_scope` (`scope`);

--
-- Indici per le tabelle `roda_sefexts`
--
ALTER TABLE `roda_sefexts`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_sefexttexts`
--
ALTER TABLE `roda_sefexttexts`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_sefmoved`
--
ALTER TABLE `roda_sefmoved`
  ADD PRIMARY KEY (`id`),
  ADD KEY `old` (`old`);

--
-- Indici per le tabelle `roda_session`
--
ALTER TABLE `roda_session`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `whosonline` (`guest`,`usertype`);

--
-- Indici per le tabelle `roda_templates_menu`
--
ALTER TABLE `roda_templates_menu`
  ADD PRIMARY KEY (`template`,`menuid`);

--
-- Indici per le tabelle `roda_template_positions`
--
ALTER TABLE `roda_template_positions`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_users`
--
ALTER TABLE `roda_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usertype` (`usertype`),
  ADD KEY `idx_name` (`name`);

--
-- Indici per le tabelle `roda_usertypes`
--
ALTER TABLE `roda_usertypes`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `roda_weblinks`
--
ALTER TABLE `roda_weblinks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`,`published`,`archived`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `roda_banner`
--
ALTER TABLE `roda_banner`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_bannerclient`
--
ALTER TABLE `roda_bannerclient`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_bannerfinish`
--
ALTER TABLE `roda_bannerfinish`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_categories`
--
ALTER TABLE `roda_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `roda_components`
--
ALTER TABLE `roda_components`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT per la tabella `roda_contact_details`
--
ALTER TABLE `roda_contact_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `roda_content`
--
ALTER TABLE `roda_content`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT per la tabella `roda_core_acl_aro`
--
ALTER TABLE `roda_core_acl_aro`
  MODIFY `aro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `roda_core_acl_aro_groups`
--
ALTER TABLE `roda_core_acl_aro_groups`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT per la tabella `roda_core_acl_aro_sections`
--
ALTER TABLE `roda_core_acl_aro_sections`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `roda_jce_langs`
--
ALTER TABLE `roda_jce_langs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `roda_jce_plugins`
--
ALTER TABLE `roda_jce_plugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT per la tabella `roda_mambots`
--
ALTER TABLE `roda_mambots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT per la tabella `roda_menu`
--
ALTER TABLE `roda_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `roda_messages`
--
ALTER TABLE `roda_messages`
  MODIFY `message_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_modules`
--
ALTER TABLE `roda_modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT per la tabella `roda_newsfeeds`
--
ALTER TABLE `roda_newsfeeds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_polls`
--
ALTER TABLE `roda_polls`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_poll_data`
--
ALTER TABLE `roda_poll_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_poll_date`
--
ALTER TABLE `roda_poll_date`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `roda_redirection`
--
ALTER TABLE `roda_redirection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT per la tabella `roda_sections`
--
ALTER TABLE `roda_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `roda_sefexts`
--
ALTER TABLE `roda_sefexts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT per la tabella `roda_sefexttexts`
--
ALTER TABLE `roda_sefexttexts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT per la tabella `roda_sefmoved`
--
ALTER TABLE `roda_sefmoved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `roda_template_positions`
--
ALTER TABLE `roda_template_positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT per la tabella `roda_users`
--
ALTER TABLE `roda_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT per la tabella `roda_weblinks`
--
ALTER TABLE `roda_weblinks`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
